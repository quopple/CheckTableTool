--[[
--	�ļ�·����	����Ӣ�ֵ���ͻ�ɱ�������.lua
--	�������ƣ�	����Ӣ�ֵ���ͻ�ɱ�������
--	����ʱ�䣺	17/11/15 15:39:39
--	���ȼ���	��
--	����ά���ˣ�	������
--	���ܲ��Ը����ˣ������
--	�߻������ˣ�	��δ
--	����������	��⾫Ӣ�ֵĻ�ɱ�͹���״̬�Ƿ���������ֹ������û�����ÿ��ֻ��һ����ҿ����������
--]]

CheckTablePath = [[..\CheckTable]]
dofile(CheckTablePath.."\\checktable.lua")
dofile(CheckTablePath.."\\clientpath.lh")
dofile([[Jx3CommonFunction/Jx3CommonFunction.lua]])

--���õ�ǰ����·��
lfs.chdir(ClientPath)

local questsTab = LoadTabList([[settings\QuestsList.tab]],"QuestID",true)
local npcTemplateTab = LoadTabList([[settings\NpcTemplateList.tab]], "ID", true)
--local npcTemplateTab = tab.Open([[settings\NpcTemplate.tab]], "ID", true)

function MemoryCollect()
	if collectgarbage("count") > 1600000 then
		check.LogError(string.format("�ڴ�ռ���ѽӽ��ٽ�ֵ����ע���޸�������%s", collectgarbage("count")))
	end
	collectgarbage("collect")
end

function TestCase()
	local szPreDescribe = "== PATH == : "
	local szTempQuestFileName = ""
	local bPrint = false

	for i, v in ipairs(questsTab) do
		local szQuestFileName = v["FileName"]
		local szQuestName = v["QuestName"]
		local bHungUp = v["HungUp"]
		if szTempQuestFileName ~= szQuestFileName then
			bPrint = false
		end

		--���û�������������nKillNpcAmount1~4������һ��Ϊ1����Ӧ���ֶ�nCanShareNpcKillByQuestEvent��Ϊ1�����Ҹ������Drop1~Drop10��Ϊnil�����������
		if bHungUp ~= 1 then
			local nQuestID = tonumber(v["QuestID"])
			local nKillNpcAmount1 = tonumber(v["KillNpcAmount1"])
			local nKillNpcAmount2 = tonumber(v["KillNpcAmount2"])
			local nKillNpcAmount3 = tonumber(v["KillNpcAmount3"])
			local nKillNpcAmount4 = tonumber(v["KillNpcAmount4"])

			if nKillNpcAmount1 == 1 then
				local nKillNpcTemplateID1 = v["KillNpcTemplateID1"]
				local NpcTemplateID1Value1 = tab.Search(npcTemplateTab, {ID = nKillNpcTemplateID1})[1]
				local nCanShareNpcKillByQuestEvent1 = tonumber(NpcTemplateID1Value1.CanShareNpcKillByQuestEvent)
				local szNpcTemplateName1 = NpcTemplateID1Value1.Name
				local bResult1 = CheckDrop(NpcTemplateID1Value1)

				if nCanShareNpcKillByQuestEvent1 ~= 1 and bResult1 == true then
					if bPrint == false then
						local szMessage = string.format("%s%s", szPreDescribe, szQuestFileName)
						check.LogError(szMessage)
						szTempQuestFileName = szQuestFileName
						bPrint = true
					end

					if nCanShareNpcKillByQuestEvent1 == nil then
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID1:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:nil, Drop1~Drop10ȫΪnil", nQuestID, szQuestName, nKillNpcTemplateID1, szNpcTemplateName1)
						check.LogError(szMessage)
					else
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID1:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:%d,  Drop1~Drop10ȫΪnil", nQuestID, szQuestName, nKillNpcTemplateID1, szNpcTemplateName1, nCanShareNpcKillByQuestEvent1)
						check.LogError(szMessage)
					end
				end
			end

			if nKillNpcAmount2 == 1 then
				local nKillNpcTemplateID2 = tonumber(v["KillNpcTemplateID2"])
				local NpcTemplateID1Value2 = tab.Search(npcTemplateTab, {ID = nKillNpcTemplateID2})[1]
				local nCanShareNpcKillByQuestEvent2 = tonumber(NpcTemplateID1Value2.CanShareNpcKillByQuestEvent)
				local szNpcTemplateName2 = NpcTemplateID1Value2.Name
				local bResult2 = CheckDrop(NpcTemplateID1Value2)

				if nCanShareNpcKillByQuestEvent2 ~= 1 and bResult2 == true then
					if bPrint == false then
						local szMessage = string.format("%s%s", szPreDescribe, szQuestFileName)
						check.LogError(szMessage)
						szTempQuestFileName = szQuestFileName
						bPrint = true
					end

					if nCanShareNpcKillByQuestEvent2 == nil then
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID2:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:nil", nQuestID, szQuestName, nKillNpcTemplateID2, szNpcTemplateName2)
						check.LogError(szMessage)
					else
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID2:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:%d,  Drop1~Drop10ȫΪnil", nQuestID, szQuestName, nKillNpcTemplateID2, szNpcTemplateName2, nCanShareNpcKillByQuestEvent2)
						check.LogError(szMessage)
					end
				end
			end

			if nKillNpcAmount3 == 1 then
				local nKillNpcTemplateID3 = tonumber(v["KillNpcTemplateID3"])
				local NpcTemplateID1Value3 = tab.Search(npcTemplateTab, {ID = nKillNpcTemplateID3})[1]
				local nCanShareNpcKillByQuestEvent3 = tonumber(NpcTemplateID1Value3.CanShareNpcKillByQuestEvent)
				local szNpcTemplateName3 = NpcTemplateID1Value3.Name
				local bResult3 = CheckDrop(NpcTemplateID1Value3)

				if nCanShareNpcKillByQuestEvent3 ~= 1 and bResult3 == true then
					if bPrint == false then
						local szMessage = string.format("%s%s", szPreDescribe, szQuestFileName)
						check.LogError(szMessage)
						szTempQuestFileName = szQuestFileName
						bPrint = true
					end

					if nCanShareNpcKillByQuestEvent3 == nil then
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID3:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:nil", nQuestID, szQuestName, nKillNpcTemplateID3, szNpcTemplateName3)
						check.LogError(szMessage)
					else
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID3:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:%d", nQuestID, szQuestName, nKillNpcTemplateID3, szNpcTemplateName3, nCanShareNpcKillByQuestEvent3)
						check.LogError(szMessage)
					end
				end
			end

			if nKillNpcAmount4 == 1 then
				local nKillNpcTemplateID4 = tonumber(v["KillNpcTemplateID4"])
				local NpcTemplateID1Value4 = tab.Search(npcTemplateTab, {ID = nKillNpcTemplateID4})[1]
				local nCanShareNpcKillByQuestEvent4 = tonumber(NpcTemplateID1Value4.CanShareNpcKillByQuestEvent)
				local szNpcTemplateName4 = NpcTemplateID1Value4.Name
				local bResult4 = CheckDrop(NpcTemplateID1Value4)

				if nCanShareNpcKillByQuestEvent4 ~= 1 and bResult4 == true then
					if bPrint == false then
						local szMessage = string.format("%s%s", szPreDescribe, szQuestFileName)
						check.LogError(szMessage)
						szTempQuestFileName = szQuestFileName
						bPrint = true
					end

					if nCanShareNpcKillByQuestEvent4 == nil then
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID4:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:nil", nQuestID, szQuestName, nKillNpcTemplateID4, szNpcTemplateName4)
						check.LogError(szMessage)
					else
						local szMessage = string.format("QuestIDΪ:%d QuestName:%s KillNpcTemplateID4:%d NpcName:%s ���ֶ� CanShareNpcKillByQuestEvent ��Ϊ1��ʵ��ֵΪ:%d", nQuestID, szQuestName, nKillNpcTemplateID4, szNpcTemplateName4, nCanShareNpcKillByQuestEvent4)
						check.LogError(szMessage)
					end
				end
			end
		end

		MemoryCollect()
	end
end

--
function CheckDrop(NpcTemplateID1Value)
	local bResult = false
	if NpcTemplateID1Value.Drop1 == "" and NpcTemplateID1Value.Drop2 == "" and NpcTemplateID1Value.Drop3 == "" and NpcTemplateID1Value.Drop4 == "" then
		if NpcTemplateID1Value.Drop5 == "" and NpcTemplateID1Value.Drop6 == "" and NpcTemplateID1Value.Drop7 == "" then
			if NpcTemplateID1Value.Drop8 == "" and NpcTemplateID1Value.Drop9 == "" and NpcTemplateID1Value.Drop10 == "" then
				bResult = true
			end
		end
	end
	return bResult
end


TestCase()


