﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kingsoft.Test.CheckTableRunner
{
    class WorkThread
    {
        private bool flag;
        private bool ThreadIsEnd;                           //该线程是否已经运行结束
        private bool ThreadFunctionIsEnd;                   //线程执行的任务函数
        private Thread thread;
        private Task task;
        private Queue<Task> TaskQueue;
        private TestSuite CurrentSuite;
        private ThreadDeal threadDeal = new ThreadDeal();

        public WorkThread(TestSuite suite, ref Queue<Task> queue)
        {
            flag = true;
            ThreadIsEnd = false;
            ThreadFunctionIsEnd = false;
            this.TaskQueue = queue;
            this.CurrentSuite = suite;
            thread = new Thread(ThreadRun);
            thread.Start();
        }

        public bool GetThreadIsEnd()
        {
            bool bResult = false;

            if (TaskQueue.Count == 0 && ThreadIsEnd)
            {
                bResult = true;
            }
            return bResult;
        }

        public void CloseThread()
        {
            flag = false;
        }

        private void ThreadRun()
        {
            while (flag && TaskQueue.Count != 0)
            {
                lock (TaskQueue)
                {
                    try
                    {
                        task = TaskQueue.Dequeue();
                    }
                    catch (Exception)
                    {
                        task = null;
                    }
                    if (task == null)
                    {
                        continue;
                    }
                }
                try
                {
                    ThreadFunctionIsEnd = threadDeal.ThreadFunction(task);
                    if (TaskQueue.Count != 0)
                    {
                        ThreadFunctionIsEnd = false;
                    }
                }
                catch (Exception)
                {
                    CurrentSuite.Logger.Info("ThreadRun is failed");
                }
            }
            if (ThreadFunctionIsEnd)
            {
                ThreadIsEnd = true;
            }
        }
    }
}
