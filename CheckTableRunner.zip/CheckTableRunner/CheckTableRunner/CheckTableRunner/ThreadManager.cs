﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kingsoft.Test.CheckTableRunner
{
    class ThreadManager
    {
        private TestSuite CurrentTestSuite;
        private int DefaultThreadNum;
        private Queue<Task> TaskQueue;
        private Queue<WorkThread> WorkThreadList;
       
        public void LazyInitializer(int ThreadNum, TestSuite Suite)
        {
            TaskQueue = new Queue<Task>();
            WorkThreadList = new Queue<WorkThread>();
            DefaultThreadNum = 4;
            CurrentTestSuite = Suite;
            foreach (var testCase in Suite.TestCaseList.Items)
            {
                TaskQueue.Enqueue(new Task(testCase, Suite));
            }
            if (ThreadNum > 0)
            {
                DefaultThreadNum = ThreadNum;
            }
            CreateThreadPool(ThreadNum);
        }

        private void CreateThreadPool(int NeedCreateThreadNum)
        {
            if (WorkThreadList == null)
            {
                WorkThreadList = new Queue<WorkThread>();
            }
            NeedCreateThreadNum = Math.Min(NeedCreateThreadNum, TaskQueue.Count);
            lock (WorkThreadList)
            {
                for (int i = 0; i < NeedCreateThreadNum; i++)
                {
                    WorkThread workthread = new WorkThread(CurrentTestSuite, ref TaskQueue);
                    WorkThreadList.Enqueue(workthread);
                }
            }
        }

        public bool ThreadIsAllClosed()
        {
            bool bResult = false;
            if (WorkThreadList.Count == 0)
            {
                bResult = true;
            }

            return bResult;
        }

        public void CloseThread()
        {
            while (WorkThreadList.Count != 0 && TaskQueue.Count == 0)
            {
                try
                {
                    WorkThread workThread = WorkThreadList.Dequeue();
                    while (true)
                    {
                        if (workThread.GetThreadIsEnd() == true)
                        {
                            workThread.CloseThread();
                            break;
                        }
                    }
                }
                catch (Exception)
                {
                }
            }
        }
    }
}
