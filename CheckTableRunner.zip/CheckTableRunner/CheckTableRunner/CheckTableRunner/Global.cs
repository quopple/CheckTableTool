﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kingsoft.Test.BBF;
using Kingsoft.Test.BBF.Xml;
using NLog;
using System.IO;
using System.Threading;

namespace Kingsoft.Test.CheckTableRunner
{
    public enum TestResultEnum { Passed = 1, Failed = 2, Error = 3, NotRun = 4 };

    public static class Global
    {
        static Global()
        {
            KXmlSerializer.LoadXmlFile("TestCaseConfig.xml", config);
        }
        //public static string SecurityKey = "MoonOnline";

        public static Semaphore mutex = new Semaphore(1, 1);
        public static ReaderWriterLockSlim LogWriteLock = new ReaderWriterLockSlim();

        private static TestCaseConfig config = new TestCaseConfig();
        public static TestCaseConfig Config
        {
            get { return config; }
        }

        public static void DeleteFile(string path)
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        public static string GetLogBackupPath(string testCasePath, TestSuite suite)
        {
            string fileName = string.Format("suite{0}_{1}_{2}.log", suite.SuiteNum, Path.GetFileNameWithoutExtension(testCasePath), DateTime.Now.ToString("HH-mm-ss"));
            string logRootPath = Path.Combine(Environment.CurrentDirectory, "TestCaseLog");
            string logFolderPath = Path.Combine(logRootPath, DateTime.Now.ToString("yyyy-MM-dd"));
            string logBackupFullPath = Path.Combine(logFolderPath, fileName);

            if (!Directory.Exists(logRootPath))
            {
                Directory.CreateDirectory(logRootPath);
            }

            if (!Directory.Exists(logFolderPath))
            {
                Directory.CreateDirectory(logFolderPath);
            }

            return logBackupFullPath;
        }

        public static List<String> GenerateMailList(TestSuite testSuite)
        {
            List<string> mailList = new List<string>();

            foreach (var mail in testSuite.MailList)
            {
                mailList.Add(mail.Address);
            }

            if (testSuite.MailAttachFile != "" && File.Exists(testSuite.MailAttachFile))
            {
                using (StreamReader mailFile = File.OpenText(testSuite.MailAttachFile))
                {
                    string mailLine = "";
                    while ( (mailLine = mailFile.ReadLine()) != null)
                    {
                        mailList.Add(mailLine);
                    }
                }
            }

            return mailList;
        }

        public static bool StartProcess(string fileName, string param, string WorkingDirectory, bool waitForExit, TestSuite suite)
        {
            try
            {
                using (System.Diagnostics.Process proc = new System.Diagnostics.Process())
                {
                    proc.StartInfo.FileName = fileName;
                    proc.StartInfo.Arguments = param;
                    proc.StartInfo.UseShellExecute = false;
                    proc.StartInfo.CreateNoWindow = false;
                    string strOutput = string.Empty;

                    if (!String.IsNullOrEmpty(WorkingDirectory))
                    {
                        proc.StartInfo.WorkingDirectory = WorkingDirectory;
                    }

                    proc.Start();

                    if (waitForExit)
                    {
                        proc.WaitForExit();
                    }
                }
            }
            catch (Exception ex)
            {
                suite.Logger.ErrorException("Exception happened in start process.", ex);
                return false;
            }

            return true;
        }

        public static void Alarm(string content)
        {
            Kingsoft.Test.AutoTest.Message.Mail.Send(GenerateAlarmMailList(), "CheckTableRunner Error!", content, true, System.Net.Mail.MailPriority.High);
        }

        public static string[] GenerateAlarmMailList()
        {
            string mailList = Global.Config.AlarmMailAddress;
            return mailList.Split(new String[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries);
        }
    }

    #region Testcase Config

    [KXmlElement]
    public class TestCaseConfig
    {
        [KXmlAttribute]
        public string LuaPath { get; set; }

        [KXmlAttribute]
        public string AlarmMailAddress { get; set; }
        
        [KXmlAttribute]
        public string MailUser { get; set; }
        
        [KXmlAttribute]
        public string MailPwd { get; set; }

        [KXmlNodeList(HasRootNode = true, ChildNodeName = "Execute")]
        public List<Execute> Setup { get; set; }

        [KXmlNodeList(HasRootNode = true, ChildNodeName = "Execute")]
        public List<Execute> Teardown { get; set; }

        [KXmlNodeList(HasRootNode = false, ChildNodeName = "TestSuite")]
        public List<TestSuite> TestSuiteList { get; set; }
    }

    [KXmlElement]
    public class TestSuite
    {
        public Logger Logger;
        public string SuiteNum;
        public List<TestCase> PassedCases = new List<TestCase>();
        public List<TestCase> FailedCases = new List<TestCase>();
        public List<TestCase> ErrorCases = new List<TestCase>();
        public List<string> Attachments = new List<string>();

        public void SetLogger(Logger logger)
        {
            Logger = logger;
        }

        public void SetSuiteNum(string suiteNum)
        {
            SuiteNum = suiteNum;
        }

        [KXmlAttribute]
        public string Name { get; set; }
        [KXmlAttribute]
        public bool NeedGlobalSetup { get; set; }

        [KXmlAttribute]
        public bool JustSendMailWhenFailed { get; set; }

        //附加的收件人
        [KXmlAttribute]
        public string MailAttachFile { get; set; }

        [KXmlAttribute]
        public bool PickScriptHeaderWhenFailed { get; set; }

        [KXmlNodeList(HasRootNode = true, ChildNodeName = "Mail")]
        public List<Mail> MailList { get; set; }

        [KXmlElement]
        public TestCaseList TestCaseList { get; set; }
    }

    [KXmlElement]
    public class TestCaseList
    {
        [KXmlAttribute]
        public string RootPath { get; set; }

        [KXmlNodeList(HasRootNode = false, ChildNodeName = "TestCase")]
        public List<TestCase> Items { get; set; }
    }

    [KXmlElement]
    public class TestCase
    {
        [KXmlAttribute]
        public string Name { get; set; }

        [KXmlAttribute]
        public string Path { get; set; }

        [KXmlAttribute]
        public bool IgnoreWarning { get; set; }

        private string personInCharge = "";
        [KXmlAttribute]
        public string PersonInCharge
        {
            get { return personInCharge; }
            set { personInCharge = value; }
        }
    }

    [KXmlElement]
    public class Mail
    {
        [KXmlAttribute]
        public string Name { get; set; }

        [KXmlAttribute]
        public string Address { get; set; }
    }

    [KXmlElement]
    public class Execute
    {
        [KXmlAttribute]
        public string Name { get; set; }

        [KXmlAttribute]
        public string Param { get; set; }
    }

    #endregion
}
