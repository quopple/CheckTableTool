﻿using System;
using NLog;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kingsoft.Test.CheckTableRunner
{
    class ThreadDeal
    {
        private  string TestLogFile = "";
        private  string RuleEnginePath = "Agenda.lua";

        public bool ThreadFunction(Task task)
        {
            string LuaLogName = "";
            string LuaLogFileName = "";
            string LuaLogFilePath = "";
            string CurrentTestCaseFullPath = "";
            TestCase CurrentTestCase = task.GetCurrentTestCase();
            TestSuite suite = task.GetCurrentSuit();

            LuaLogFileName = string.Format("suite{0}_{1}.log", suite.SuiteNum, CurrentTestCase.Name);
            LuaLogFilePath = Path.Combine(Global.Config.LuaPath, "log");
            LuaLogFilePath = Path.Combine(LuaLogFilePath, LuaLogFileName);

            TestResultEnum result = TestResultEnum.NotRun;

            LuaLogName = LuaLogFilePath.Replace("**", "imp_");          //解决不是别含有**的路径名问题
            result = RunOneCase(suite, CurrentTestCase, LuaLogName, CurrentTestCaseFullPath);

            switch (result)
            {
                case TestResultEnum.Passed:
                    lock (suite.PassedCases)
                    {
                        suite.PassedCases.Add(CurrentTestCase);
                    }
                    break;

                case TestResultEnum.Failed:
                    lock (suite.FailedCases)
                    {
                        suite.FailedCases.Add(CurrentTestCase);
                    }
                    lock (suite.Attachments)
                    {
                        suite.Attachments.Add(TestLogFile);
                    }
                    break;

                case TestResultEnum.Error:
                    lock (suite.ErrorCases)
                    {
                        suite.ErrorCases.Add(CurrentTestCase);
                    }
                    break;
                default:
                    break;
            }

            lock (suite.Logger)
            {
                suite.Logger.Info(String.Format("Case '{0}' finished. Result: {1}", CurrentTestCase.Name, result.ToString()));
            }

            return true;
        }

        private TestResultEnum RunOneCase(TestSuite CurrentTestSuite, TestCase CurrentTestCase, string LuaLogFilePath, string CurrentTestCaseFullPath)
        {
            try
            {
                
                Global.DeleteFile(LuaLogFilePath);
                while (true)
                {
                    Thread.Sleep(1000);
                    if (!File.Exists(LuaLogFilePath))
                    {
                        break;
                    }
                }

                CurrentTestCaseFullPath = Path.Combine(CurrentTestSuite.TestCaseList.RootPath, CurrentTestCase.Path);

                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.FileName = Path.Combine(Global.Config.LuaPath, "lua.exe");
                //startInfo.Arguments = String.Format("-e \"io.stdout:setvbuf 'no'\" \"{0}\"  \"{1}\"  \"{2}\"", RuleEnginePath, LuaLogFilePath,CurrentTestCaseFullPath);
                startInfo.Arguments = String.Format("\"{0}\"  \"{1}\"  \"{2}\"", RuleEnginePath, LuaLogFilePath, CurrentTestCaseFullPath);

                startInfo.WorkingDirectory = Path.Combine(System.Environment.CurrentDirectory, "RuleEngine");

                using (Process proc = Process.Start(startInfo))
                {
                    proc.WaitForExit();

                    if (proc.ExitCode == 0)
                    {
                        return ProcessResult(LuaLogFilePath, CurrentTestSuite, CurrentTestCase, CurrentTestCaseFullPath);
                    }
                    else
                    {
                        lock (CurrentTestSuite.Logger)
                        {
                            CurrentTestSuite.Logger.Error(String.Format("Error happened in running test case '{0}'. Exit Code:{1}", CurrentTestCase.Name, proc.ExitCode));
                        }
                        return TestResultEnum.Error;
                    }
                }
            }
            catch (System.Exception ex)
            {
                lock (CurrentTestSuite.Logger) 
                {
                    CurrentTestSuite.Logger.ErrorException("Exception happened. ", ex); 
                }
                lock (CurrentTestSuite.Logger)
                {
                    CurrentTestSuite.Logger.Error(String.Format("Case name：{0}<br/>Exception：{1}<br/>", CurrentTestCase.Name, ex));
                }
                Global.Alarm(String.Format("Case name：{0}<br/>Exception：{1}<br/>", CurrentTestCase.Name, ex));
                return TestResultEnum.Error;
            }
        }

        private TestResultEnum ProcessResult(string LuaLogFilePath, TestSuite CurrentTestSuite, TestCase CurrentTestCase, string CurrentTestCaseFullPath)
        {
            TestResultEnum testResult = TestResultEnum.Passed;

            if (File.Exists(LuaLogFilePath))
            {
                string errorContent = "";

                using (StreamReader sr = new StreamReader(LuaLogFilePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains("[Error]"))
                        {
                            testResult = TestResultEnum.Failed;
                            errorContent += line + "\r\n";
                        }
                        else if (!CurrentTestCase.IgnoreWarning)
                        {
                            if (line.Contains("[Warn]"))
                            {
                                if (line.Contains("same key"))
                                {
                                    string tempString = line.Trim();
                                    char tempChar = tempString[tempString.Length - 1];

                                    if (tempChar != ':')
                                    {
                                        testResult = TestResultEnum.Failed;
                                        errorContent += line + "\r\n";
                                    }
                                }
                            }
                        }
                    }

                    if (testResult == TestResultEnum.Failed)
                    {
                        // pick script header when failed
                        if (CurrentTestSuite.PickScriptHeaderWhenFailed)
                        {
                            String script = File.ReadAllText(CurrentTestCaseFullPath, Encoding.Default);
                            String header = script.Substring(0, script.IndexOf("--]]") + 4);
                            errorContent = String.Format("{0}\r\n{1}", header, errorContent);
                        }

                        // write running log
                        string logBackupFullPath = Global.GetLogBackupPath(CurrentTestCaseFullPath, CurrentTestSuite);
                        File.WriteAllText(logBackupFullPath, errorContent);
                        TestLogFile = logBackupFullPath;
                    }
                }
            }

            return testResult;
        }

    }
}
