﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kingsoft.Test.CheckTableRunner
{
    public class Task
    {
        private TestCase CurrentTestCase;
        private TestSuite CurrentSuite;
        public Task(TestCase testCase, TestSuite suite)
        {
            CurrentTestCase = testCase;
            CurrentSuite = suite;
        }

        public TestCase GetCurrentTestCase()
        {
            return CurrentTestCase;
        }

        public TestSuite GetCurrentSuit()
        {
            return CurrentSuite;
        }
    }
}
