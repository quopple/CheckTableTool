﻿using System;
using NLog;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Net.Mail;

namespace Kingsoft.Test.CheckTableRunner
{
    class Program
    {
        private static int noNeedGlobalSetupCount = 0;
        private static TestSuite CurrentTestSuite = null;
        private static List<Thread> ThreadList = new List<Thread>();
        static void Main(string[] args)
        {
            TestSuite suite = null;
            int ThreadCount = 4;
            if (args.Length != 0)   //通过.bat来调用CheckTableRunner.exe
            {
                int Index = int.Parse(args[0]);
                suite = Global.Config.TestSuiteList[Index];
                string SuiteLogFilePath = Path.Combine(System.Environment.CurrentDirectory, suite.Name);
                Logger Log = NlogInfo.logger(SuiteLogFilePath);
                suite.SetLogger(Log); 
                suite.SetSuiteNum(args[0]);
                if (Global.Config.TestSuiteList.Count > 1)
                {
                    ThreadCount /= Global.Config.TestSuiteList.Count;
                }

                CheckOneSuiteAndSendMail(suite, ThreadCount);
            }
            else                   //直接点击CheckTableRunner.exe运行
            {
                int SuiteNum = 0;
                foreach (var item in Global.Config.TestSuiteList)
                {
                    suite = item;
                    string SuiteLogFilePath = Path.Combine(System.Environment.CurrentDirectory, suite.Name);
                    Logger Log = NlogInfo.logger(SuiteLogFilePath);
                    suite.SetLogger(Log);
                    suite.SetSuiteNum(SuiteNum.ToString());
                    if (Global.Config.TestSuiteList.Count > 1)
                    {
                        ThreadCount /= Global.Config.TestSuiteList.Count;
                    }
                    CheckOneSuiteAndSendMail(suite, ThreadCount);
                    SuiteNum++;
                }
            }
            
        }

        static void CheckOneSuiteAndSendMail(TestSuite suite, int ThreadCount)
        {
            try
            {
                suite.Logger.Info("================================CheckTableRunner Start===============================");
                suite.Logger.Info("Test start...");
                if (suite.NeedGlobalSetup == false)
                {
                    noNeedGlobalSetupCount++;
                    RunTestSuite(suite, ThreadCount);
                }

                if (Setup(suite))
                {
                    if (suite.NeedGlobalSetup)
                    {
                        RunTestSuite(suite, ThreadCount);
                    }
                }

                else
                {
                    suite.Logger.Error("Error happened in setup.");
                    Global.Alarm("Error happened in setup.");
                }
                suite.Logger.Info("Test finished.");

                // teardown
                Teardown(suite);
            }
            catch (Exception ex)
            {
                suite.Logger.ErrorException("Error happened.", ex);
            }
        }

        static void RunTestSuite(TestSuite suite, int ThreadCount)
        {
            suite.Logger.Info(String.Format("TestSuite '{0}' start...", suite.Name));
            CurrentTestSuite = suite;

            // clean list
            CurrentTestSuite.PassedCases.Clear();
            CurrentTestSuite.FailedCases.Clear();
            CurrentTestSuite.ErrorCases.Clear();
            CurrentTestSuite.Attachments.Clear();

            ThreadManager threadManager = new ThreadManager();
            try
            {
                threadManager.LazyInitializer(ThreadCount, suite);
            }
        
            catch (System.Exception ex)
            {
                lock (suite.Logger)
                {
                    suite.Logger.ErrorException("Exception happened.", ex);
                }
                Global.Alarm(String.Format("Exception happened in running suite {0}. <br/>Detail:{1}", suite.Name, ex.Message));
            }
            while (true)
            {
                threadManager.CloseThread();
                if (threadManager.ThreadIsAllClosed() == true)
                {
                    break;
                }
            }

            suite.Logger.Info(String.Format("TestSuite '{0}' finished.", suite.Name));
           
            SendReport(suite);
        }

        static void SendReport(TestSuite suite)
        {
            suite.Logger.Info("Sending mail start...");

            int totalTestCaseCount = CurrentTestSuite.TestCaseList.Items.Count;

            // generate mail content
            string body = File.ReadAllText("CheckTableMailTemplate.htm", Encoding.UTF8);
            double passRateValue = (double)CurrentTestSuite.PassedCases.Count / (double)totalTestCaseCount;
            string passRate = passRateValue == 0 ? "0%" : passRateValue.ToString("##.##%");

            // replace mark
            body = body.Replace("$$SuiteName$$", CurrentTestSuite.Name);
            if (totalTestCaseCount != CurrentTestSuite.PassedCases.Count)  // failed
            {
                body = body.Replace("$$Result$$", "<font color='red'>Failed</font>");
                body = body.Replace("$$PassRate$$", String.Format("<font color='red'>{0}</font>", passRate));
                body = body.Replace("$$Message$$", "失败案例的运行日志请见邮件附件");
            }
            else    // passed
            {
                body = body.Replace("$$Result$$", "<font color='green'>Passed</font>");
                body = body.Replace("$$PassRate$$", String.Format("<font color='green'>{0}</font>", passRate));
                body = body.Replace("$$Message$$", "");
            }

            body = body.Replace("$$TotalCount$$", totalTestCaseCount.ToString());
            body = body.Replace("$$PassCount$$", CurrentTestSuite.PassedCases.Count.ToString());
            body = body.Replace("$$FailedCount$$", CurrentTestSuite.FailedCases.Count.ToString());
            body = body.Replace("$$ErrorCount$$", CurrentTestSuite.ErrorCases.Count.ToString());
            body = body.Replace("$$NotRunCount$$", "0");
            body = body.Replace("$$PassList$$", String.Join("<br/>", (from c in CurrentTestSuite.PassedCases select c.Name).ToArray()));
            body = body.Replace("$$FailedList$$", String.Join("<br/>", (from c in CurrentTestSuite.FailedCases select c.Name).ToArray()));
            body = body.Replace("$$ErrorList$$", String.Join("<br/>", (from c in CurrentTestSuite.ErrorCases select c.Name).ToArray()));
            body = body.Replace("$$NotRunList$$", "");

            // send mail
            if (totalTestCaseCount == CurrentTestSuite.PassedCases.Count && CurrentTestSuite.JustSendMailWhenFailed) // passed and JustSendMailWhenFailed == true
            {
                // just send passed mail to alarm receiver
                /* 
                AutoTest.Message.Mail.Send(Global.GenerateAlarmMailList(), String.Format("{0} 执行结果", CurrentTestSuite.Name), body, true,
                                       System.Net.Mail.MailPriority.High, Attachments.ToArray());
                */
                
                SendMail(Global.GenerateAlarmMailList(), String.Format("{0} 执行结果", CurrentTestSuite.Name), body);
            }
            else if (CurrentTestSuite.JustSendMailWhenFailed)
            {
                /*
                AutoTest.Message.Mail.Send(Global.GenerateMailList(CurrentTestSuite), String.Format("{0} 执行结果", CurrentTestSuite.Name), body, true,
                                       System.Net.Mail.MailPriority.High, Attachments.ToArray());
                */ 
                
                SendMail(Global.GenerateMailList(CurrentTestSuite), String.Format("{0} 执行结果", CurrentTestSuite.Name), body);

                // deal with failed cases, send mail group by PersonInCharge
                //DealWithFailedCases();
            }

            suite.Logger.Info("Sending mail finished.");
        }

        static void DealWithFailedCases()
        {
            List<TestCase> tempFailedCases = new List<TestCase>();
            foreach (var item in CurrentTestSuite.FailedCases)
            {
                string[] tempMailAdd = item.PersonInCharge.Split(new String[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var mailAdd in tempMailAdd)
                {
                    tempFailedCases.Add(new TestCase { Name = item.Name, Path = item.Path, IgnoreWarning = item.IgnoreWarning, PersonInCharge = mailAdd });
                }
            }

            // send mail group by PersonInCharge
            var personGroup = from item in tempFailedCases
                              group item by item.PersonInCharge into groups
                              select new { Address = groups.First().PersonInCharge, List = groups };

            foreach (var item in personGroup)
            {
                if (!String.IsNullOrEmpty(item.Address))
                {
                    string failedBody = File.ReadAllText("FailedMailTemplate.htm", Encoding.UTF8);
                    failedBody = failedBody.Replace("$$SuiteName$$", CurrentTestSuite.Name);
                    failedBody = failedBody.Replace("$$Result$$", "<font color='red'>Failed</font>");
                    failedBody = failedBody.Replace("$$FailedCount$$", item.List.Count().ToString());
                    failedBody = failedBody.Replace("$$FailedList$$", String.Join("<br/>", (from c in item.List select c.Name).ToArray()));

                    /*
                    AutoTest.Message.Mail.Send(new string[] { item.Address }, String.Format("{0} 执行结果", CurrentTestSuite.Name), failedBody, true,
                                       System.Net.Mail.MailPriority.High, Attachments.ToArray());

                    */ 
                    
                    SendMail(new string[] { item.Address }, String.Format("{0} 执行结果", CurrentTestSuite.Name), failedBody);
                }
            }
        }

        static bool Setup(TestSuite suite)
        {
            suite.Logger.Info("Setupping...");
            // run global setup
            suite.Logger.Info("Starting global setup...");
            foreach (var item in Global.Config.Setup)
            {
                if (Global.StartProcess(item.Name, item.Param, null, true, suite))
                {
                    suite.Logger.Info(String.Format("Execute succeed. {0}", String.Format("{0} {1}", item.Name, item.Param)));
                }
                else
                {
                    suite.Logger.Error(String.Format("Execute error. {0}", String.Format("{0} {1}", item.Name, item.Param)));
                    return false;
                }

                Thread.Sleep(2 * 1000);
            }

            return true;
        }

        static bool Teardown(TestSuite suite)
        {
            suite.Logger.Info("Teardowning...");

            suite.Logger.Info("Starting config teardown...");
            foreach (var item in Global.Config.Teardown)
            {
                if (Global.StartProcess(item.Name, item.Param, null, true, suite))
                {
                    suite.Logger.Info(String.Format("Execute succeed. {0}", String.Format("{0} {1}", item.Name, item.Param)));
                }
                else
                {
                    suite.Logger.Error(String.Format("Execute error. {0}", String.Format("{0} {1}", item.Name, item.Param)));
                    return false;
                }
            }

            return true;
        }

        static void SendMail(IList<string> receivers, string subject, string body)
        {
            if(String.IsNullOrEmpty(Global.Config.MailUser) || String.IsNullOrEmpty(Global.Config.MailPwd))
            {
                AutoTest.Message.Mail.Send(receivers, subject, body, true, MailPriority.High, CurrentTestSuite.Attachments.ToArray());
            }
            else
            {
                //SmtpClient client = new SmtpClient();
                //client.Host = "zhmail.kingsoft.com";
                //client.Port = 25;
                //client.UseDefaultCredentials = true;
                //client.Credentials = new System.Net.NetworkCredential(Global.Config.MailUser, Global.Config.MailPwd);

                //BBF.Report.Email.SendFromSMTP("baiyinzu@kingsoft.com", "baiyinzu", receivers, subject, Attachments.ToArray(), body, true, MailPriority.High, client);

                AutoTest.Message.Mail.Send(receivers, subject, body, true, MailPriority.High, CurrentTestSuite.Attachments.ToArray());
            }
        }
    }
}
