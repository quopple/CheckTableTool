﻿using System;
using NLog;
using System.IO;
using NLog.Config;
using NLog.Targets;
using NLog.Win32.Targets; 
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kingsoft.Test.CheckTableRunner
{
    public static class NlogInfo
    {
        public static NLog.Logger logger(string SuiteLogFilePath)
        {
            LoggingConfiguration lc = new LoggingConfiguration();

            ColoredConsoleTarget consoleTarget = new ColoredConsoleTarget();
            lc.AddTarget("console", consoleTarget);

            FileTarget fileTarget = new FileTarget();
            lc.AddTarget("file", fileTarget);

            consoleTarget.Layout = "[${level}] ${message} ${exception:format=ShortType,Message}";
            fileTarget.FileName = SuiteLogFilePath;
            fileTarget.Layout = "[${date:format=MM-dd HH\\:mm\\:ss}][${level}] ${message} ${exception:format=ShortType,Message,StackTrace}";
            fileTarget.Encoding = "utf-8";

            LoggingRule rule1 = new LoggingRule("*", NLog.LogLevel.Info, consoleTarget);
            lc.LoggingRules.Add(rule1);

            LoggingRule rule2 = new LoggingRule("*", NLog.LogLevel.Info, fileTarget);
            lc.LoggingRules.Add(rule2);

            NLog.LogManager.Configuration = lc;
            Logger loggertemp = NLog.LogManager.GetLogger("NlogInfo");

            return loggertemp;
        } 
    }
}
