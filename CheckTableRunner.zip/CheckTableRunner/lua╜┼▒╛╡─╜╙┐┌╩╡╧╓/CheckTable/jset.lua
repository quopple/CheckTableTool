require "set"

require "jdebug"
require "check"

--[[Convert set s into a list table.
--]]
function set.tolist(s)
	local list = {}
	for k, _ in pairs(s) do
		table.insert(list, k)
	end
	return list
end

local function test()
	local s = set.new({"1", "2", "3"})
	local l = set.tolist(s)
	l = table.sort(l)
	check.Equals(3, #l)
	check.Equals("1", l[1])
	check.Equals("2", l[2])
	check.Equals("3", l[3])
end

if debug.isMain() then test() end
