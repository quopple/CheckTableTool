module ("string", package.seeall)

require "table"
require "string"
require "string_ext"
require "list"

--[[������תΪstring��������Ե�ʱ�������
--]]
function arrayToString(array)
	local tRet = {}
	if type(array) == "table" then
		for _,v in ipairs(array) do
			table.insert(tRet, arrayToString(v))
		end
		return "{"..table.concat(tRet, ",").."}"
	elseif type(array) == "string" then
		return "'"..array.."'"
	else
		return tostring(array)
	end
end

--[[���ݷָ���delim��str��ɶ�����ַ�����maxNb����������ַ���������
--]]
function split(str, delim, maxNb)
    -- Eliminate bad cases...
    if string.find(str, delim) == nil then
        return { str }
    end
    if maxNb == nil or maxNb < 1 then
        maxNb = 0    -- No limit
    end
    local result = {}
    local pat = "(.-)" .. delim .. "()"
    local nb = 0
    local lastPos
    for part, pos in string.gfind(str, pat) do
        nb = nb + 1
        result[nb] = part
        lastPos = pos
        if nb == maxNb then break end
    end
    -- Handle the last field
    if nb ~= maxNb then
        result[nb + 1] = string.sub(str, lastPos)
    end
    return result
end

--[[�ж��ַ���str�Ƿ���subStr��ʼ��
--]]
function startsWith(str, subStr)
	local subLen = string.len(subStr)
	if string.len(str) < subLen then
		return false
	end
	
	return string.sub(str, 0, subLen) == subStr
end

--[[�ж��ַ���str�Ƿ���subStr������
--]]
function endsWith(str, subStr)
	local subLen = string.len(subStr)
	if string.len(str) < subLen then
		return false
	end
	
	return string.sub(str, -subLen) == subStr
end

local function test()
	local t = {1,2,name="����",table={'a','b','c'}}
	print(string.arrayToString(t))
	print(string.arrayToString(string.split("abc", "b")))
	
	print(string.startsWith("abc", "ab"))
	print(string.startsWith("abc", "cd"))
	print(string.endsWith("abc", "bc"))
	print(string.endsWith("abc", "ab"))
end

require "debug"
if debug.getinfo(1, "S").source == "@jstring.lua" then
	test()
end
