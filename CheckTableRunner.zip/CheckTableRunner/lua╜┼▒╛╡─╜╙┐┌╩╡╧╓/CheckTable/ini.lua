module("ini", package.seeall)

require "io"
require "unclasslib"

require "jdotnet"
require "jstring"
require "jdebug"
require "pl.config"

function Open(fileName)
	local result = pl.config.read(fileName)
	return result
end

function GetValue(self, nodeName, name)
	return self[nodeName][name]
end

local function test()
	local tttb = Open("F:\\Trunk\\client\\data\\source\\maps\\�����\\�����.Map.Logical")
	local sss = GetValue(tttb, "Doodad47", "szName")
	print(sss)
end

if debug.isMain() then test() end