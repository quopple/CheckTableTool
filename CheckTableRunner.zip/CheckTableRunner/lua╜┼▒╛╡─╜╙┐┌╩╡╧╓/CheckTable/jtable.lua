module("table", package.seeall)

require "table"
require "table_ext"

require "jstring"
require "check"
require "jdebug"

--[[��tableתΪstring��������Ե�ʱ�������
--]]
function toString(t)
	local tRet = {}
	if type(t) == "table" then
		for k, v in pairs(t) do
			if type(k) == "number" then
				table.insert(tRet, "["..k.."]="..toString(v))
			else
				table.insert(tRet, k.."="..toString(v))
			end
		end
		return "{"..table.concat(tRet, ",").."}"
	elseif type(t) == "string" then
		return "'"..t.."'"
	else
		return tostring(t)
	end
end

--[[�Ƚ�����table�Ƿ���ͬ��
--]]
function equals(t1, t2)
	if type(t1) ~= type(t2) then
		return false
	end
	
	if type(t1) == "table" then
		if #t1 ~= #t2 then
			return false
		end
		
		local countT1 = 0
		for k, _ in pairs(t1) do
			if not string.startsWith(k, "__") then --skip __index and etc.
				countT1 = countT1 + 1
			end
		end
		local countT2 = 0
		for k, _ in pairs(t2) do
			if not string.startsWith(k, "__") then --skip __index and etc.
				countT2 = countT2 + 1
			end
		end

		if countT1 ~= countT2 then
			return false
		end
		
		for k, v in pairs(t1) do
			if not string.startsWith(k, "__") then --skip __index and etc.
				if not equals(v, t2[k]) then
					return false
				end
			end
		end
	else
		return t1 == t2
	end
	
	return true
end

--[[��table��index���°�˳�����У���maxIndex֮�ڵ���������ѹ����
--]]
function arrangeIndex(t, maxIndex)
	local index = 1
	for currIndex = 1, maxIndex do
		if t[currIndex] then
			if currIndex ~= index then
				t[index] = t[currIndex]
				t[currIndex] = nil
			end
			index = index + 1
		end
	end
end

--[[�ж�t���Ƿ����ָ����ֵ��
--]]
function hasValue(t, value)
	for _, v in ipairs(t) do
		if v == value then
			return true
		end
	end
	return false
end

function union(table1, table2)
	local result = {}
	for k, v in pairs(table2) do
		result[k] = v
	end
	for k, v in pairs(table1) do
		result[k] = v
	end
	return result
end

local function test()
	check.IsTrue(table.equals("abc", "abc"), 'table.equals("abc", "abc")')
	check.IsFalse(table.equals("abc", {"abc"}), 'table.equals("abc", {"abc"})')
	
	check.IsTrue(table.equals({1,2,3,name="name",{4,5,6}}, {1,2,3,name="name",{4,5,6}}), 'table.equals({1,2,3,name="name",{4,5,6}}, {1,2,3,name="name",{4,5,6}})')
	check.IsFalse(table.equals({1,2,3,name="name",{4,5,6}}, {1,2,3,name="name",{4,5,7}}), 'table.equals({1,2,3,name="name",{4,5,6}}, {1,2,3,name="name",{4,5,7}})')
	
	local t = {1,2,3,name="name",{4,5,6}}
	t.__index = t
	check.IsTrue(table.equals(t, {1,2,3,name="name",{4,5,6}}), 'ignore __index')
	
	t = {[1] = 1, [3] = 3, [5] = 5}
	arrangeIndex(t, 5)
	
	check.Equals(3, #t, "arrangeIndex(t) #t")
	check.Equals(1, t[1], "arrangeIndex(t) t[1]")
	check.Equals(3, t[2], "arrangeIndex(t) t[2]")
	check.Equals(5, t[3], "arrangeIndex(t) t[3]")
	
	check.IsTrue(table.hasValue({"a", "b", "c"}, "b"), "table.hasValue")
	check.IsFalse(table.hasValue({"a", "b", "c"}, "d"), "table.hasValue")
end

if debug.isMain() then test() end
