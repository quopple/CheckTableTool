﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using NPOI.HSSF.UserModel;

namespace CheckTable
{
    public class ExcelTabFile : TabFile
    {
        public ExcelTabFile()
        {
        }

        public ExcelTabFile(string fileName)
            : base(fileName)
        {
        }

        public ExcelTabFile(string fileName, string idColumn)
            : base(fileName, idColumn)
        {
        }

        public ExcelTabFile(string fileName, Encoding encoding)
            : base(fileName, encoding)
        {
        }

        public ExcelTabFile(string fileName, Encoding encoding, bool titleOnly)
            : base(fileName, encoding, titleOnly)
        {
        }

        /// <summary>
        /// For Lua.
        /// </summary>
        public void LoadFileWithSheetName(string fileName, string sheetName, int startRow = 1, bool titleOnly = false)
        {
            LoadFile(fileName, sheetName, startRow, titleOnly);
        }

        /// <summary>
        /// For Lua.
        /// </summary>
        public void LoadFileWithSheetIndex(string fileName, int sheetIndex, int startRow = 1, bool titleOnly = false)
        {
            LoadFile(fileName, sheetIndex, startRow, titleOnly);
        }

        public override void LoadFile(string fileName, Encoding encoding, bool titleOnly)
        {
            LoadFile(fileName, 1, 1, titleOnly);
        }

        private IExcelTabFileLoader GetExcelLoader(string fileName)
        {
            var ext = Path.GetExtension(fileName);
            IExcelTabFileLoader excelLoader = null;
            if (ext.Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
            {
                excelLoader = new Excel2007TabFileLoader(this);
            }
            else
            {
                excelLoader = new Excel2003TabFileLoader(this);
            }
            return excelLoader;
        }

        public void LoadFile(string fileName, string sheetName, int startRow = 1, bool titleOnly = false)
        {
            var excelLoader = GetExcelLoader(fileName);
            excelLoader.LoadFile(fileName, sheetName, startRow, titleOnly);
        }

        public void LoadFile(string fileName, int sheetIndex = 1, int startRow = 1, bool titleOnly = false)
        {
            var excelLoader = GetExcelLoader(fileName);
            excelLoader.LoadFile(fileName, sheetIndex, startRow, titleOnly);
        }

        public override void SaveFile(string fileName, Encoding encoding)
        {
            var excelLoader = GetExcelLoader(fileName);
            excelLoader.SaveFile(fileName);
        }

    }

}
