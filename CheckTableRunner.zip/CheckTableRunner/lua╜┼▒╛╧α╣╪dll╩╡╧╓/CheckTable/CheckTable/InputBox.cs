﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckTable
{
    public partial class InputBox : Form
    {
        private string keyWords;
    

        public string KeyWords
        {
            get
            {
                return keyWords;
            }
        }

        public InputBox()
        {
            InitializeComponent();
        }


        private void button_ok_Click(object sender, EventArgs e)
        {
            keyWords = textBox_KeyWords.Text;

            if (radioButton_mode1.Checked)
                DataIO.InputMode = 1;

            if (radioButton_mode2.Checked)
                DataIO.InputMode = 2;

            if (radioButton_mode3.Checked)
                DataIO.InputMode = 3;
            

            this.Close();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void InputBox_Load(object sender, EventArgs e)
        {
            this.AcceptButton = button_ok;
            this.CancelButton = button_exit;
        }
    }
}
