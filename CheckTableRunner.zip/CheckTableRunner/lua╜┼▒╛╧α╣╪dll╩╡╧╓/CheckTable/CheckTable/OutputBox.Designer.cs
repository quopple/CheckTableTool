﻿namespace CheckTable
{
    partial class OutputBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView_OutputBox = new System.Windows.Forms.ListView();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listView_OutputBox
            // 
            this.listView_OutputBox.Location = new System.Drawing.Point(25, 21);
            this.listView_OutputBox.Name = "listView_OutputBox";
            this.listView_OutputBox.Size = new System.Drawing.Size(485, 196);
            this.listView_OutputBox.TabIndex = 0;
            this.listView_OutputBox.UseCompatibleStateImageBehavior = false;
            this.listView_OutputBox.View = System.Windows.Forms.View.Details;
            this.listView_OutputBox.SelectedIndexChanged += new System.EventHandler(this.listView_OutputBox_SelectedIndexChanged);
            // 
            // button_ok
            // 
            this.button_ok.Location = new System.Drawing.Point(121, 242);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 1;
            this.button_ok.Text = "确定";
            this.button_ok.UseVisualStyleBackColor = true;
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(301, 242);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(75, 23);
            this.button_exit.TabIndex = 2;
            this.button_exit.Text = "退出";
            this.button_exit.UseVisualStyleBackColor = true;
            // 
            // OutputBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 286);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.listView_OutputBox);
            this.Name = "OutputBox";
            this.Text = "OutputBox";
            this.Load += new System.EventHandler(this.OutputBox_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView_OutputBox;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_exit;
    }
}