﻿using System;
using NLog; 
using NLog.Config;
using NLog.Targets;
using NLog.Win32.Targets; 
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CheckTable
{
    public static class LuaHelper
    {
        //需要动态更改lua脚本的Log日志路径使用该方法创建logger对象
        public static NLog.Logger CreateLoggerByAutoPath(string LuaLogName)
        {
            // 1. 创建configuration对象
            LoggingConfiguration lc = new LoggingConfiguration();

            // 2. 创建targets并且添加到configuration 
            ColoredConsoleTarget consoleTarget = new ColoredConsoleTarget();
            lc.AddTarget("console", consoleTarget);

            FileTarget fileTarget = new FileTarget();
            lc.AddTarget("file", fileTarget);

            // 3. 设置target属性
            consoleTarget.Layout = "[${level}] ${message} ${exception:format=ShortType,Message}";
            fileTarget.FileName = LuaLogName;
            fileTarget.Layout = "[${level}] ${message} ${exception:format=ShortType,Message,StackTrace}";
            fileTarget.Encoding = "utf-8";

            // 4. 定义路由规则
            LoggingRule rule1 = new LoggingRule("*", NLog.LogLevel.Info, consoleTarget);
            lc.LoggingRules.Add(rule1);

            LoggingRule rule2 = new LoggingRule("*", NLog.LogLevel.Info, fileTarget);
            lc.LoggingRules.Add(rule2);

            NLog.LogManager.Configuration = lc;
            Logger loggertemp = LogManager.GetLogger("LuaHelper");
            return loggertemp;            
        }

        //不需要动态更改lua脚本的Log日志路径，直接使用使用该logger对象
        public static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
    }
}
