﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;

namespace CheckTable
{
    public class AssemblyLoadResolver
    {
        static AssemblyLoadResolver()
        {
            //The AssemblyResolve event is called when the common language runtime tries to bind to the assembly and fails.
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.AssemblyResolve += new ResolveEventHandler(currentDomain_AssemblyResolve);
        }

        private static List<string> dotNetLibPaths = new List<string>();

        public static void AddPath(string path)
        {
            dotNetLibPaths.Add(path);
        }

        public static void RemovePath(string path)
        {
            dotNetLibPaths.Remove(path);
        }

        static Assembly currentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            // This event will be fired only when CLR cannot find the assembly itself.
            int commaPos = args.Name.IndexOf(",");
            string reqName;
            if (commaPos == -1)
            {
                reqName = args.Name;
            }
            else
            {
                reqName = args.Name.Substring(0, commaPos);
            }

            foreach (string dotNetLibPath in dotNetLibPaths)
            {
                string assemblyPath = Path.Combine(dotNetLibPath, reqName) + ".dll";
                if (File.Exists(assemblyPath))
                {
                    return Assembly.LoadFrom(assemblyPath);
                }
            }
            return null;
        }
    }
}
