﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckTable
{
    public partial class OutputBox : Form
    {
        public OutputBox()
        {
            InitializeComponent();
        }

        private void OutputBox_Load(object sender, EventArgs e)
        {
            var showList = DataIO.resaultTable;
            var headerList = DataIO.resaultTableHeader;
            listView_OutputBox.BeginUpdate();
            try
            {
                listView_OutputBox.Columns.Clear();
                foreach (var item in headerList)
                {
                    listView_OutputBox.Columns.Add(item, 40, HorizontalAlignment.Center);
                }

                for (int i = 0; i < showList.Count; i++)
                {
                    ListViewItem item = new ListViewItem();
                    item.SubItems.Clear();
                    item.SubItems[0].Text = showList[i][0];
                    for (int j = 1; j < showList[i].Count; j++)
                    {
                        item.SubItems.Add(showList[i][j]);
                    }
                    listView_OutputBox.Items.Add(item);
                }
                
                for (int m = 0; m < listView_OutputBox.Columns.Count; m++)
                {
                    listView_OutputBox.Columns[m].Width = -2;
                }
            }
            finally
            {
                listView_OutputBox.EndUpdate();
            }
            this.AcceptButton = button_ok;
            this.CancelButton = button_exit;
        }

        private void listView_OutputBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
