﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CheckTable
{
    class DataIO
    {
        private static DataIO dataIO;

        public static DataIO GetInstance()
        {
            if (dataIO == null)
                dataIO = new DataIO();
            return dataIO;
        }

        private static int inputMode;

        public static int InputMode
        {
            get
            {
                return inputMode;
            }

            set
            {
                inputMode = value;
            }
        }

        private static List<List<string>> resaultTab = new List<List<string>>();

        private static List<string> resaultHeader = new List<string>();

        public static List<List<string>> resaultTable
        {
            get
            {
                return resaultTab;
            }
        }

        public static List<string> resaultTableHeader
        {
            get
            {
                return resaultHeader;
            }
        }


        public List<string> GetHeader()
        {
            return resaultTableHeader;
        }

        public List<string> InputData()
        {
            var inputData = new List<string>();
            var dlg = new InputBox();
            dlg.ShowDialog();
            var key = dlg.KeyWords;
            if (!key.Contains(";"))
                inputData.Add(key);
            else
            {
                var keyArray = key.Split(';');
                foreach (var item in keyArray)
                {
                    inputData.Add(item);
                }
            }
            return inputData;
        }

        public int GetMode()
        {
            return InputMode;  
        }

        public int GetListCount(List<string> inputData)
        {
            return inputData.Count;
        }

        public void ShowConsole()
        {
            var dlg = new OutputBox();
            dlg.ShowDialog();
        }

        public List<string> CreateNewRow()
        {
            var row = new List<string>();
            return row;
        }

        public void AddRow(List<string> row)
        {
            resaultTab.Add(row);
        }
    }
}
