﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CheckTable
{
    interface IExcelTabFileLoader
    {
        void LoadFile(string fileName, string sheetName, int startRow, bool titleOnly);
        void LoadFile(string fileName, int sheetIndex, int startRow, bool titleOnly);
        void SaveFile(string fileName);
    }
}
