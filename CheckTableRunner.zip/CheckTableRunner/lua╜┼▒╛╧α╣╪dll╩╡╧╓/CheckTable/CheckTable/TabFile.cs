﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;

namespace CheckTable
{
    /// <summary>
    /// Tab文件的读写类。
    /// Tab文件类似CSV文件，不同之处仅在于分隔符为\t。
    /// </summary>
    public class TabFile : IEnumerable
    {
        public TabFileHeader Headers { get; set; }

        public IList<TabFileRow> Rows
        {
            get
            {
                return rows;
            }
        }

        private List<TabFileRow> rows = new List<TabFileRow>();

        public TabFileRow AddRow()
        {
            if (Headers == null)
            {
                return null;
            }

            var row = new TabFileRow(this, Headers.Count);
            for (int i = 0; i < Headers.Count; i++)
            {
                row.Add(string.Empty);
            }

            Rows.Add(row);

            return row;
        }

        public static Encoding DefaultEncoding = null;

        public TabFile()
        {
            HasDefaultRow = false;
        }

        public TabFile(string fileName)
        {
            LoadFile(fileName);
        }

        public TabFile(string fileName, string idColumn)
        {
            LoadFile(fileName);
            IdColumn = idColumn;
        }

        public TabFile(string fileName, string idColumn, bool hasDefaultRow)
        {
            LoadFile(fileName);
            IdColumn = idColumn;
            HasDefaultRow = hasDefaultRow;
        }

        public TabFile(string fileName, Encoding encoding)
        {
            LoadFile(fileName, encoding);
        }

        public TabFile(string fileName, Encoding encoding, bool titleOnly)
        {
            LoadFile(fileName, encoding, titleOnly);
        }

        public void LoadFile(string fileName)
        {
            LoadFile(fileName, DefaultEncoding == null ? Encoding.Default : DefaultEncoding);
        }

        public void LoadFile(string fileName, Encoding encoding)
        {
            LoadFile(fileName, encoding, false);
        }

        /// <summary>
        /// Load a tab file of filename.
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="encoding"></param>
        /// <param name="titleOnly"></param>
        public virtual void LoadFile(string fileName, Encoding encoding, bool titleOnly)
        {
            // 为了方便调试，被锁定的文件依然允许打开。
            using (var reader = new StreamReader(
                new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), encoding))
            {
                // Read headers
                var headerLine = reader.ReadLine();
                Headers = new TabFileHeader(this, headerLine.Split('\t'));

                if (!titleOnly)
                {
                    // Read contents line by line
                    string line = string.Empty;
                    line = reader.ReadLine();
                    while (!string.IsNullOrEmpty(line))
                    {
                        rows.Add(new TabFileRow(this, line.Split('\t')));
                        line = reader.ReadLine();
                    }
                }
            }
        }

        public virtual void SaveFile(string filename, Encoding encoding = null)
        {
            if (encoding == null)
            {
                encoding = DefaultEncoding;
            }

            var dir = Path.GetDirectoryName(filename);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            using (var writer = new StreamWriter(filename, false, encoding))
            {
                // Write headers
                writer.WriteLine(string.Join("\t", Headers.ToArray()));

                // Write contents line by line
                foreach (var row in Rows)
                {
                    writer.WriteLine(string.Join("\t", row.ToArray()));
                }
            }
        }

        private string idColumn = null;

        private Dictionary<int, TabFileRow> idRowDict = null;

        public string IdColumn
        {
            get
            {
                return idColumn;
            }
            set
            {
                idColumn = value;
                var colIndex = Headers[idColumn];

                idRowDict = new Dictionary<int, TabFileRow>(Rows.Count);

                foreach (var row in Rows)
                {
                    idRowDict.Add(int.Parse(row[colIndex]), row);
                }
            }
        }

        // 用于兼容lua传递的字符串表示的数字。
        public TabFileRow this[string idString]
        {
            get
            {
                if (string.IsNullOrEmpty(idString))
                {
                    return null;
                }

                int id;
                if (int.TryParse(idString, out id))
                {
                    return this[id];
                }
                else
                {
                    return null;
                }
            }
        }

        public TabFileRow this[int id]
        {
            get
            {
                if (string.IsNullOrEmpty(IdColumn))
                {
                    return null;
                }

                TabFileRow result;
                idRowDict.TryGetValue(id, out result);
                return result;
            }
        }

        /// <summary>
        /// 如果HasDefaultRow == true，那么第一行是默认值行。
        /// 于是在TabFileRow上用列名取值的时候，如果值本身为""，那么取第一行对应的默认值。
        /// </summary>
        public bool HasDefaultRow { get; set; }

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return rows.GetEnumerator();
        }

        #endregion

    }

    public class TabFileRow : List<string>
    {
        public TabFileRow(TabFile owner, IEnumerable<string> collection)
            : base(collection)
        {
            ownerTabFile = owner;
        }

        public TabFileRow(TabFile owner, int capacity)
            : base(capacity)
        {
            ownerTabFile = owner;
        }

        public TabFileRow(TabFile owner)
        {
            ownerTabFile = owner;
        }

        private TabFile ownerTabFile;

        public string this[string column]
        {
            get
            {
                var colIndex = ownerTabFile.Headers[column];
                // 如果没有这个cell，避免抛异常。
                if (colIndex == -1 || colIndex >= Count)
                {
                    return "";
                }
                var value = this[colIndex];
                // 按需要取默认值
                if (ownerTabFile.HasDefaultRow && string.IsNullOrEmpty(value))
                {
                    value = ownerTabFile.Rows[0][colIndex];
                }
                return value;
            }
        }

        public override bool Equals(object obj)
        {
            var b = (TabFileRow)obj;
            if (Count != b.Count)
            {
                return false;
            }

            for (int i = 0; i < Count; i++)
            {
                if (this[i] != b[i])
                {
                    return false;
                }
            }

            return true;
        }

        public override int GetHashCode()
        {
            return string.Join("", this.ToArray()).GetHashCode();
        }

        public static bool operator ==(TabFileRow a, TabFileRow b)
        {
            return a.Equals(b);
        }

        public static bool operator !=(TabFileRow a, TabFileRow b)
        {
            return !(a == b);
        }
    }

    public class TabFileHeader : List<string>
    {
        public TabFileHeader(TabFile owner)
        {
            ownerTabFile = owner;
        }

        public TabFileHeader(TabFile owner, IEnumerable<string> collection)
            : base(collection)
        {
            ownerTabFile = owner;
        }

        private TabFile ownerTabFile;

        public int this[string column]
        {
            get
            {
                if (nameDict == null)
                {
                    nameDict = new Dictionary<string, int>(Count);
                    for (int i = 0; i < Count; i++)
                    {
                        // 忽略空字符串
                        var header = this[i].Trim();
                        if (!string.IsNullOrEmpty(header))
                        {
                            // 忽略重复的header
                            if(!nameDict.ContainsKey(header))
                            {
                                nameDict.Add(this[i], i);
                            }
                        }
                    }
                }

                int index;
                if(nameDict.TryGetValue(column, out index))
                {
                    return index;
                }
                else
                {
                    return -1;
                }
            }
        }

        private Dictionary<string, int> nameDict = null;
    }
}
