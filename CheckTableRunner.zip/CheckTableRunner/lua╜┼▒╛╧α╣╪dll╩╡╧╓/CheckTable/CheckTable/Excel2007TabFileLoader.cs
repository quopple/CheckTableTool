﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OfficeOpenXml;
using System.IO;

namespace CheckTable
{
    class Excel2007TabFileLoader : IExcelTabFileLoader
    {
        private ExcelTabFile excelTabFile;

        public Excel2007TabFileLoader(ExcelTabFile excelTabFile)
        {
            this.excelTabFile = excelTabFile;
        }

        public void LoadFile(string fileName, string sheetName, int startRow, bool titleOnly)
        {
            using (var excel = new ExcelPackage(new FileInfo(fileName)))
            {
                LoadSheet(excel.Workbook.Worksheets[sheetName], startRow, titleOnly);
            }
        }

        public void LoadFile(string fileName, int sheetIndex, int startRow, bool titleOnly)
        {
            using (var excel = new ExcelPackage(new FileInfo(fileName)))
            {
                LoadSheet(excel.Workbook.Worksheets[sheetIndex], startRow, titleOnly);
            }
        }

        private void LoadSheet(ExcelWorksheet sheet, int startRow, bool titleOnly)
        {
            excelTabFile.Headers = new TabFileHeader(excelTabFile);
            var dimention = new ExcelWorkSheetDimension(sheet);
            startRow = Math.Max(startRow, dimention.FirstRow);

            for (var headIndex = 1; headIndex <= dimention.LastCol; headIndex++)
            {
                excelTabFile.Headers.Add(sheet.Cell(startRow, headIndex).Value);
            }

            if (!titleOnly)
            {
                for (var rowIndex = startRow + 1; rowIndex <= dimention.LastRow; rowIndex++)
                {
                    var isEmptyRow = true;
                    var row = new TabFileRow(excelTabFile);
                    for (var colIndex = 1; colIndex <= dimention.LastCol; colIndex++)
                    {
                        var value = sheet.Cell(rowIndex, colIndex).Value;
                        row.Add(value);

                        if (value != "")
                        {
                            isEmptyRow = false;
                        }
                    }

                    if (!isEmptyRow) // 空行则跳过
                    {
                        excelTabFile.Rows.Add(row);
                    }
                }
            }
        }

        public void SaveFile(string fileName)
        {
            throw new NotImplementedException();
        }
    }
}
