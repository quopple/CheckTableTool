﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.HSSF.UserModel;
using System.IO;
using NPOI.SS.UserModel;

namespace CheckTable
{
    class Excel2003TabFileLoader : IExcelTabFileLoader
    {
        private ExcelTabFile excelTabFile;

        public Excel2003TabFileLoader(ExcelTabFile excelTabFile)
        {
            this.excelTabFile = excelTabFile;
        }

        public void LoadFile(string fileName, string sheetName, int startRow, bool titleOnly)
        {
            using (var workBook = new HSSFWorkbook(new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
            {
                LoadSheet(workBook, workBook.GetSheet(sheetName), startRow, titleOnly);
            }
        }

        public void LoadFile(string fileName, int sheetIndex, int startRow, bool titleOnly)
        {
            using (var workBook = new HSSFWorkbook(new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
            {
                LoadSheet(workBook, workBook.GetSheetAt(sheetIndex - 1), startRow, titleOnly);
            }
        }

        private void LoadSheet(HSSFWorkbook workBook, Sheet sheet, int startRow, bool titleOnly)
        {
            excelTabFile.Headers = new TabFileHeader(excelTabFile);
            var excelHead = sheet.GetRow(startRow - 1);
            var cellFormatter = new DataFormatter();
            var formulaEvaluator = new HSSFFormulaEvaluator(workBook);

            // LastCellNum是最后一个单元格的index - 1(0 based)。
            for (int headIndex = 0; headIndex < excelHead.LastCellNum; headIndex++)
            {
                var cell = excelHead.GetCell(headIndex);
                excelTabFile.Headers.Add(cellFormatter.FormatCellValue(cell, formulaEvaluator));
            }

            if (!titleOnly)
            {
                // LastRowNum是最后一行index(0 based)。
                for (int rowIndex = excelHead.RowNum + 1; rowIndex <= sheet.LastRowNum; rowIndex++)
                {
                    var excelRow = sheet.GetRow(rowIndex);

                    if (excelRow.LastCellNum != -1) // 空行则跳过
                    {
                        var isEmptyRow = true;
                        var row = new TabFileRow(excelTabFile, excelRow.LastCellNum - 1);
                        for (int colIndex = 0; colIndex < excelRow.LastCellNum; colIndex++)
                        {
                            var cell = excelRow.GetCell(colIndex);
                            var value = cell == null ? "" : cellFormatter.FormatCellValue(cell, formulaEvaluator);
                            row.Add(value);

                            if (value != "")
                            {
                                isEmptyRow = false;
                            }
                        }

                        if (!isEmptyRow) // 空行则跳过
                        {
                            excelTabFile.Rows.Add(row);
                        }
                    }
                }
            }
        }

        public void SaveFile(string fileName)
        {
            var workbook = new HSSFWorkbook();
            var sheet = workbook.CreateSheet("Sheet1");

            var headerRow = sheet.CreateRow(0);
            for (int col = 0; col < excelTabFile.Headers.Count; col++)
            {
                headerRow.CreateCell(col).SetCellValue(excelTabFile.Headers[col]);
            }

            for (var rowIndex = 0; rowIndex < excelTabFile.Rows.Count; rowIndex++)
            {
                var tabRow = excelTabFile.Rows[rowIndex];
                var excelRow = sheet.CreateRow(rowIndex + 1);
                for (int colIndex = 0; colIndex < tabRow.Count; colIndex++)
                {
                    excelRow.CreateCell(colIndex).SetCellValue(tabRow[colIndex]);
                }
            }

            using (var file = new FileStream(fileName, FileMode.Create))
            {
                workbook.Write(file);
            }
        }

    }

}
