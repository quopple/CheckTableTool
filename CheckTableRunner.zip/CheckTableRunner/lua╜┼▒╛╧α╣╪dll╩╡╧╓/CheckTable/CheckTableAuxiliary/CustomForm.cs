﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace CheckTableAuxiliary
{
    class CustomForm
    {

        private Dictionary<int, List<Control>> controlMap = new Dictionary<int, List<Control>>();

        private Dictionary<int, int> heightRecord = new Dictionary<int, int>();
        private Dictionary<int, int> widthRecord = new Dictionary<int, int>();

        public Dictionary<TextBox, List<ComboBox>> textWithComboBoxMap = new Dictionary<TextBox, List<ComboBox>>();

        public string Context { get; set; }
        public string ComboState { get; set; }

        private Dictionary<int, int> collumnGap = new Dictionary<int, int>();
        private int commonCollumnGap = 0;

        private Dictionary<int, int> rowGap = new Dictionary<int, int>();
        private int commonRowGap = 0;

        public List<TextBox> textBoxList = new List<TextBox>();
        public List<ComboBox> comboboxList = new List<ComboBox>();

        public List<string> textboxTextList = new List<string>();
        public List<string> comboBoxStateList = new List<string>();
        public int ControlCount { get; set; }

        private Form form;
        private int formRow = 0;
        private List<DataItem> dataList = new List<DataItem>();

        private string formName = "";
        private int horizontalSize = 10;
        private int verticalSize = 15;

        public List<DataItem> DataList
        {
            get
            {
                return dataList;
            }

        }
        public class DataItem
        {
            public string textBoxContext;
            public string comboBoxState;
        }

        private static CustomForm customForm;

        public static CustomForm GetInstance()
        {
            if (customForm == null)
            {
                customForm = new CustomForm();
            }
            return customForm;
        }

        public List<string> ProcessTextbox(TextBox textbox)
        {
            var inputData = new List<string>();
            var key = textbox.Text;
            //saveName = dlg.SaveFileName;

            int stringIndex = 0;
            while (stringIndex < key.Length)
            {
                if (key[stringIndex] == '{')
                {
                    var endindex = key.IndexOf('}', stringIndex);
                    inputData.Add(key.Substring(stringIndex, endindex - stringIndex + 1));
                    stringIndex = endindex;
                }
                else if (key[stringIndex] != ',')
                {
                    inputData.Add(char.ToString(key[stringIndex]));
                }
                stringIndex++;
            }
            return inputData;
        }

        public void SetFormName(string name)
        {
            formName = name;
        }

        public void SetRowGap(int startRow, int endRow, int size)
        {
            if (startRow == 0 && endRow == 0)
            {                commonRowGap = size;
                return;
            }
            rowGap[startRow] = size;
        }

        public void SetCollumnGap(int row, int size)
        {
            if (row == 0)
            {
                commonCollumnGap = size;
                return;
            }
            collumnGap[row] = size;
        }

        public void AddControl(int tag, string name, int width, int height, string userData)
        {
            var control = CreateControl(name, width, height, userData);
            var row = formRow + tag;

            if (row == 0)
            {
                Console.WriteLine("请开辟一个新行添加控件");
                return;
            }

            if (tag > 0)
                formRow++;

            var list = (from o in controlMap
                        where o.Key == row
                        select o.Value).FirstOrDefault();

            if (list == null)
            {
                var controlList = new List<Control>();
                controlMap[row] = controlList;
            }
            controlMap[row].Add(control);
        }

        public void Bind(int textboxId, int comboboxId)
        {
            if (!textWithComboBoxMap.ContainsKey(textBoxList[textboxId]))
            {
                textWithComboBoxMap[textBoxList[textboxId]] = new List<ComboBox>();
            }
            textWithComboBoxMap[textBoxList[textboxId]].Add(comboboxList[comboboxId]);

        }

        public void SetEdge(int horizontal, int vertical)
        {
            horizontalSize = horizontal;
            verticalSize = vertical;
        }

        private int GetMaxWidth(List<int> widthList)
        {
            var maxWitdh = 0;
            foreach (var item in widthList)
            {
                if (item > maxWitdh)
                {
                    maxWitdh = item;
                }
            }

  
            return maxWitdh;
            //注意是client的大小
        }

        private void ResizeForm(int clientWidth, int clientHeight)
        {
            form.ClientSize = new Size(clientWidth, clientHeight);
            
        }

  
        public void ShowForm()
        {
            form = new Form();
            form.Text = formName;
            var widthPerRow = new List<int>();
            var formColGap = 0;
            var formRowGap = 0;
            var currentHeight = verticalSize;
            foreach (var item in controlMap)
            {
                var row = item.Key;

                if (collumnGap.ContainsKey(row))
                    formColGap = collumnGap[row];
                else
                    formColGap = commonCollumnGap;

                if (rowGap.ContainsKey(row))
                    formRowGap = rowGap[row];

                else
                    formRowGap = commonRowGap;

                var x = horizontalSize;
                var y = currentHeight;
                var maxControlHeight = 0;
                foreach (var control in item.Value)
                {
                    control.SetBounds(x + control.Margin.Left, y + control.Margin.Top, control.Width, control.Height);
                    form.Controls.Add(control);

                    x += control.Width + formColGap + control.Margin.Right;
                    if (control.Height > maxControlHeight)
                    {
                        maxControlHeight = control.Height + control.Margin.Bottom;
                    }
                }
                widthPerRow.Add(x - formColGap);
                currentHeight += maxControlHeight + formRowGap;
            }

            int formWidth = GetMaxWidth(widthPerRow) + horizontalSize;

            var button_ok = new Button() { Text = "确认" };
            var button_exit = new Button() { Text = "退出" };

            var bottomGap = (formWidth - 2 * button_ok.Width - 2 *horizontalSize
                                - button_ok.Margin.Left - button_ok.Margin.Right
                                - button_ok.Margin.Left - button_ok.Margin.Right) / 3;

            button_ok.SetBounds(horizontalSize + bottomGap + button_ok.Margin.Left, 
                                currentHeight + button_ok.Margin.Top, button_ok.Width, button_exit.Height);

            button_exit.SetBounds(horizontalSize + button_ok.Width + 2*bottomGap + button_exit.Margin.Left
                                , currentHeight + button_exit.Margin.Top, button_ok.Width, button_exit.Height);
            form.Controls.Add(button_ok);
            form.Controls.Add(button_exit);
            currentHeight += button_ok.Height + button_exit.Margin.Bottom;

            button_ok.Click += delegate(Object sender, EventArgs e)
            {
                foreach (var textbox in textBoxList)
                {
                    var item = new DataItem();
                    item.textBoxContext = textbox.Text;
                    item.comboBoxState = GetBindComboBoxState(textbox);
                    dataList.Add(item);
                }
                form.Close();
            };

            button_exit.Click += delegate(Object sender, EventArgs e)
            {
                form.Close();
            };

            var formHeight = currentHeight + verticalSize;
            ResizeForm(formWidth, formHeight);
            form.ShowDialog();
        
        }

        public int GetListCount(List<string> inputData)
        {
            return inputData.Count;
        }

        public List<string> GetTextBoxContext(int id)
        {
            var textbox = textBoxList[id];
            return ProcessTextbox(textbox);
        }

        public string GetBindComboBoxState(TextBox textbox)
        {
            List<ComboBox> comboList = null;
            var combotext = "";
            if (textWithComboBoxMap.ContainsKey(textbox))
            {
                comboList = textWithComboBoxMap[textbox];
            }
            else
            {
                return "No_ComboText";
            }
            foreach (var item in comboList)
            {
                if (item.SelectedItem != null)
                {
                    if (combotext == "")
                    {
                        combotext = item.SelectedItem.ToString();
                    }
                    else
                    {
                        combotext += ',' + item.SelectedItem.ToString();
                    }
                }
            }
            return combotext;
        }

        public string GetComboBoxState(int id)
        {
            return comboboxList[id].SelectedItem.ToString();
        }

        public Control CreateControl(string type, int width, int height, string userData)
        {
            Control controlItem = new Control();
            switch (type)
            {
                case "Button":
                    var button = new Button();
                    button.Text = userData;
                    controlItem = button;
                    break;

                case "ComboBox":
                    var comboBox = new ComboBox();
                    foreach (var itemName in userData.Split(new char[] { ',' }))
                    {
                        comboBox.Items.Add(itemName);
                    }
                    comboBox.SelectedIndex = 0;
                    controlItem = comboBox;
                    comboboxList.Add(comboBox);
                    break;

                case "TextBox":
                    var textBox = new TextBox();
                    textBox.Text = userData;
                    controlItem = textBox;
                    textBoxList.Add(textBox);
                    break;
                case "Label":
                    var label = new Label();
                    label.AutoSize = true;
                    label.Text = userData;
                    label.TextAlign = ContentAlignment.MiddleLeft;
                    label.Margin = new Padding(0, 3, 3, 0);
                    controlItem = label;
                    break;
                default:
                    break;
            }

            if (width != 0)
            {
                controlItem.Width = width;
            }

            if (height != 0)
            {
                controlItem.Height = height;
            }
      
            return controlItem;
        }




    }
}
