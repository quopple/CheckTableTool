﻿namespace CheckTableAuxiliary
{
    partial class InputBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_KeyWords = new System.Windows.Forms.TextBox();
            this.radioButton_mode1 = new System.Windows.Forms.RadioButton();
            this.radioButton_mode2 = new System.Windows.Forms.RadioButton();
            this.radioButton_mode3 = new System.Windows.Forms.RadioButton();
            this.button_ok = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.输入查询内容 = new System.Windows.Forms.Label();
            this.保存文件名 = new System.Windows.Forms.Label();
            this.textBox_saveName = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_KeyWords
            // 
            this.textBox_KeyWords.Location = new System.Drawing.Point(86, 3);
            this.textBox_KeyWords.Name = "textBox_KeyWords";
            this.textBox_KeyWords.Size = new System.Drawing.Size(303, 21);
            this.textBox_KeyWords.TabIndex = 0;
            // 
            // radioButton_mode1
            // 
            this.radioButton_mode1.AutoSize = true;
            this.radioButton_mode1.Location = new System.Drawing.Point(9, 30);
            this.radioButton_mode1.Name = "radioButton_mode1";
            this.radioButton_mode1.Size = new System.Drawing.Size(53, 16);
            this.radioButton_mode1.TabIndex = 1;
            this.radioButton_mode1.TabStop = true;
            this.radioButton_mode1.Text = "模式1";
            this.radioButton_mode1.UseVisualStyleBackColor = true;
            // 
            // radioButton_mode2
            // 
            this.radioButton_mode2.AutoSize = true;
            this.radioButton_mode2.Location = new System.Drawing.Point(128, 30);
            this.radioButton_mode2.Name = "radioButton_mode2";
            this.radioButton_mode2.Size = new System.Drawing.Size(53, 16);
            this.radioButton_mode2.TabIndex = 2;
            this.radioButton_mode2.TabStop = true;
            this.radioButton_mode2.Text = "模式2";
            this.radioButton_mode2.UseVisualStyleBackColor = true;
            // 
            // radioButton_mode3
            // 
            this.radioButton_mode3.AutoSize = true;
            this.radioButton_mode3.Location = new System.Drawing.Point(259, 30);
            this.radioButton_mode3.Name = "radioButton_mode3";
            this.radioButton_mode3.Size = new System.Drawing.Size(53, 16);
            this.radioButton_mode3.TabIndex = 3;
            this.radioButton_mode3.TabStop = true;
            this.radioButton_mode3.Text = "模式3";
            this.radioButton_mode3.UseVisualStyleBackColor = true;
            // 
            // button_ok
            // 
            this.button_ok.Location = new System.Drawing.Point(336, 55);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 4;
            this.button_ok.Text = "确认";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.输入查询内容);
            this.panel1.Controls.Add(this.保存文件名);
            this.panel1.Controls.Add(this.textBox_saveName);
            this.panel1.Controls.Add(this.textBox_KeyWords);
            this.panel1.Controls.Add(this.radioButton_mode1);
            this.panel1.Controls.Add(this.radioButton_mode2);
            this.panel1.Controls.Add(this.button_ok);
            this.panel1.Controls.Add(this.radioButton_mode3);
            this.panel1.Location = new System.Drawing.Point(3, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(414, 85);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // 输入查询内容
            // 
            this.输入查询内容.AutoSize = true;
            this.输入查询内容.Location = new System.Drawing.Point(3, 6);
            this.输入查询内容.Name = "输入查询内容";
            this.输入查询内容.Size = new System.Drawing.Size(77, 12);
            this.输入查询内容.TabIndex = 8;
            this.输入查询内容.Text = "输入查询内容";
            // 
            // 保存文件名
            // 
            this.保存文件名.AutoSize = true;
            this.保存文件名.Location = new System.Drawing.Point(9, 55);
            this.保存文件名.Name = "保存文件名";
            this.保存文件名.Size = new System.Drawing.Size(65, 12);
            this.保存文件名.TabIndex = 7;
            this.保存文件名.Text = "保存文件名";
            // 
            // textBox_saveName
            // 
            this.textBox_saveName.Location = new System.Drawing.Point(86, 55);
            this.textBox_saveName.Name = "textBox_saveName";
            this.textBox_saveName.Size = new System.Drawing.Size(232, 21);
            this.textBox_saveName.TabIndex = 6;
            // 
            // InputBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 104);
            this.Controls.Add(this.panel1);
            this.Name = "InputBox";
            this.Text = "InputBox";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InputBox_FormClosing);
            this.Load += new System.EventHandler(this.InputBox_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_KeyWords;
        private System.Windows.Forms.RadioButton radioButton_mode1;
        private System.Windows.Forms.RadioButton radioButton_mode2;
        private System.Windows.Forms.RadioButton radioButton_mode3;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_saveName;
        private System.Windows.Forms.Label 保存文件名;
        private System.Windows.Forms.Label 输入查询内容;
    }
}