﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Jx3Common;
using System.IO;

namespace CheckTableAuxiliary
{
    public class LuaDataIO
    {
        private static LuaDataIO luadataIO;
        private static TabFile tabFile = new TabFile();
        private CustomForm customForm = CustomForm.GetInstance();

        public static LuaDataIO GetInstance()
        {
            if (luadataIO == null)
                luadataIO = new LuaDataIO();
            return luadataIO;
        }

        private static int inputMode;

        public static int InputMode
        {
            get
            {
                return inputMode;
            }

            set
            {
                inputMode = value;
            }
        }

        private List<List<string>> resultTab = new List<List<string>>();

        private List<string> resultHeader = new List<string>();

        public List<List<string>> ResultTableContent
        {
            get
            {
                return resultTab;
            }
        }

        public List<string> ResultTableHeader
        {
            get
            {

                return resultHeader;
            }
        }

        public void  InitializeTable()
        {
            resultTab.Clear();
            resultHeader.Clear();
        }   

        public string GetFlsChdir()
        {
            try
            {
                var cmdLine = Environment.GetCommandLineArgs();    
                if (cmdLine != null)
                {
                    return cmdLine[2];
                }
                return "";
            }
            catch (IndexOutOfRangeException)
            {
                return "";
            }
            catch (NullReferenceException)
            {
                return "";
            }
        }

        public void ShowDialog()
        {
            customForm.ShowForm();
        }

        public void AddControl(int tag, string name, int width, int height, string userData)
        {
            customForm.AddControl(tag, name, width, height, userData);
        }

        public void ControlBind(int tId, int cId)
        {
            customForm.Bind(tId, cId);
        }

        public List<string> GetInputContext(int id)
        {
            var inputData = new List<string>();
            //ShowDialog();
            var dataList = customForm.DataList;
            if (dataList.Count > 0)
            {
                var textContext = dataList[id].textBoxContext;

                if (!textContext.Contains('{') && !textContext.Contains(','))
                {
                    inputData.Add(textContext);
                }
                else
                {
                    int stringIndex = 0;
                    while (stringIndex < textContext.Length)
                    {
                        if (textContext[stringIndex] == '{')
                        {
                            var endindex = textContext.IndexOf('}', stringIndex);
                            inputData.Add(textContext.Substring(stringIndex, endindex - stringIndex + 1));
                            stringIndex = endindex;
                        }
                        else if (textContext[stringIndex] != ',')
                        {
                            var endindex = textContext.IndexOf(',', stringIndex);
                            if (endindex == -1)
                            {
                                inputData.Add(textContext.Substring(stringIndex));
                                break;
                            }

                            inputData.Add(textContext.Substring(stringIndex, endindex - stringIndex));
                            stringIndex = endindex;
                        }
                        stringIndex++;
                    }
                }
            }
            return inputData;
        }

        public void SetEdge(int hor, int ver)
        {
            customForm.SetEdge(hor, ver);
        }

        public void SetRowGap(int startRow, int endRow, int size)
        {
            customForm.SetRowGap(startRow, endRow, size);
        }

        public void SetCollumnGap(int row, int size)
        {
            customForm.SetCollumnGap(row,size);
        }
    
        public string GetBindComboboxState(int id)
        {
            var state = "No_Context";
            var dataList = CustomForm.GetInstance().DataList;
            if (dataList.Count > 0)
            {
                state = dataList[id].comboBoxState;
            }
            return state;
        }

        public string GetComboBoxState(int id)
        {
            return customForm.GetComboBoxState(id);
        }

        public int GetListCount(List<string> inputData)
        {
            return inputData.Count;
        }

        public void ProcessResult(string saveName)
        {
            var createTab = new OutputToTab();
            createTab.CreateTab(saveName, ResultTableHeader, ResultTableContent);
        }

        public List<string> CreateNewRow()
        {
            var row = new List<string>();
            return row;
        }

        public void CreateTable()
        {
            ResultTableContent.Clear();
            //Console.WriteLine(resaultTable.Count);
        }
        public void AddRow(List<string> row)
        {
            //Console.WriteLine(resaultTable.Count);
            ResultTableContent.Add(row);
        }

        public void SetFormName(string name)
        {
            customForm.SetFormName(name);
        }
    }
}
