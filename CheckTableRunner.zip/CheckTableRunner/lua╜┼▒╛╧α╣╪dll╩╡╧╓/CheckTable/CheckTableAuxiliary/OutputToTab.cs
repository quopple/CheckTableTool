﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Jx3Common;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace CheckTableAuxiliary
{
    class OutputToTab
    {
        public void CreateTab(string fileName, List<string> tabHeader, List<List<string>> tabContent)
        {
            var tabFile = new TabFile();

            tabFile.Headers = new List<string>();

            if (tabHeader[0].StartsWith("ID"))
            {
                tabFile.Headers.Add("\"" + tabHeader[0] + "\"");
            }
            else
                tabFile.Headers.Add(tabHeader[0]);


            for (int i = 1; i < tabHeader.Count; i++)
            {
                tabFile.Headers.Add(tabHeader[i]);
            }

            foreach (List<string> row in tabContent)
            {
                tabFile.Rows.Add(row);
            }

            //SaveTab(fileName);

            OpenTab(SaveTab(fileName, tabFile));

            System.Threading.Thread.Sleep(1000);
        }

        private string SaveTab(string fileName, TabFile tabFile)
        {
            string currentPath = "";
            string scriptName = "";
            var commandArgs = Environment.GetCommandLineArgs();
           
            //Console.WriteLine("savetab");
            //Console.WriteLine(commandArgs);
            foreach (var item in commandArgs)
            {
                //Console.WriteLine("EachItem:" + item);
    
                if (Path.GetExtension(item) == ".lua")
                {
                    //Console.WriteLine("item:" + item);
                    scriptName = Path.GetFileNameWithoutExtension(item).ToString();
                    //Console.WriteLine("scriptName:" + scriptName);
                    currentPath = Path.GetDirectoryName(item);
                    //Console.WriteLine("currentPath:" + currentPath);
                }
            }
            var resaultPath = currentPath + @"\" + scriptName;
            //Console.WriteLine("resaultPath:" + resaultPath);
            string saveName = "";
            if (fileName != "")
            {
                saveName = Path.Combine(resaultPath, scriptName + "_" + fileName + ".tab");
            }
            else
            {
                var date = DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour +
                                    "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second;
             
                var date2 = DateTime.Now.ToLocalTime().ToString().Replace(" ", "_");
                //Console.WriteLine("resaultPath:" + resaultPath);
                saveName = Path.Combine(resaultPath, scriptName + "_" + date + ".tab");
                //Console.WriteLine("saveName:" + saveName);
            }
            tabFile.SaveFile(saveName, Encoding.GetEncoding("GB2312"));
            //Console.WriteLine("--------------------------------------");
            return saveName;
        }

        private void OpenTab(string filePath)
        {
            var startInfo = new ProcessStartInfo()
            {
                FileName = "Excel.exe",
                UseShellExecute = true,
                Arguments = filePath,
            };
            using (Process.Start(startInfo)) { }
        }
    }
}

