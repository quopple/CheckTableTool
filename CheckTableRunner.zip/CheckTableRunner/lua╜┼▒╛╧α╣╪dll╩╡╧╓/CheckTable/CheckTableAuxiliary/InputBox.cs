﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Jx3Common;

namespace CheckTableAuxiliary
{
    public partial class InputBox : Form
    {
        private string keyWords;
        private string saveFileName;

        public string SaveFileName
        {
            get
            {
                return saveFileName;
            }
        }

        public string KeyWords
        {
            get
            {
                return keyWords;
            }
        }

        public InputBox()
        {
            InitializeComponent();
        }


        private void button_ok_Click(object sender, EventArgs e)
        {
            
            keyWords = textBox_KeyWords.Text;


            //if (textBox_saveName.Text == null || textBox_saveName.Text == "")
            //{
            //    MessageBox.Show("请输入查询内容");
            //    return;
            //}
            saveFileName = (textBox_saveName.Text == null) ? "" :
                                                        textBox_saveName.Text;

                if (radioButton_mode1.Checked)
                    LuaDataIO.InputMode = 1;

                if (radioButton_mode2.Checked)
                    LuaDataIO.InputMode = 2;

                if (radioButton_mode3.Checked)
                    LuaDataIO.InputMode = 3;
                this.Close();      
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void InputBox_Load(object sender, EventArgs e)
        {
            
         
            var inputBoxName = LuaDataIO.InputBoxName;
            var modeExpressCollection = LuaDataIO.RadioButtonExpress;

            if (inputBoxName != "")
            {
                this.Text = inputBoxName;
            }

            //foreach (var item in modeExpressCollection)
            //{
            //    if (item.Value != "")
            //    {
            //        var radioButton = new RadioButton();
            //        radioButton.Name = item.Value;
            //        this.Controls.Add(radioButton);
            //    }
            //}


            if (modeExpressCollection.ContainsKey(1))
                radioButton_mode1.Text = modeExpressCollection[1];


            if (modeExpressCollection.ContainsKey(2))
                radioButton_mode2.Text = modeExpressCollection[2];


            if (modeExpressCollection.ContainsKey(3))
                radioButton_mode3.Text = modeExpressCollection[3];

            radioButton_mode1.Checked = true;
            this.AcceptButton = button_ok;
        }

        private void button_saveFile_Click(object sender, EventArgs e)
        {
            var dlg = new SaveFileDialog();
            dlg.Filter = " tab files(*.tab)|*.tab|All files(*.*)|*.*";
            dlg.ShowDialog(this);
            
                var path = dlg.FileName;
                SaveToTab(path);
            
        }

        private void SaveToTab(string saveAddress)
        {
            //var tabHeaders = LuaDataIO.resaultTableHeader;
            //var tabRows = LuaDataIO.resaultTable;

            //TabFile tabFile = new TabFile();

            //foreach (var item in tabHeaders)
            //{
            //    tabFile.Headers.Add(item);
            //}3

            //foreach (var rows in tabRows)
            //{
            //    tabFile.Rows.Add(rows);
            //}

            //tabFile.SaveFile(saveAddress, Encoding.UTF8);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void InputBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.textBox_KeyWords == null)
                keyWords = "";

        }
    }
}
