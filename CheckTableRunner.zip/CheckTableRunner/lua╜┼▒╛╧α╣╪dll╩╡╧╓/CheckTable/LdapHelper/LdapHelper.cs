﻿/*/////////////////////////////////////////////////////////////////////////////////////////////////
 * 本类为LDAP验证模块
 * 接受用户名和用户密码，然胡将其连接到域服务器进行验证
 * //////////////////////////////////////////////////////////////////////////////////////////////*/
using System.DirectoryServices;
using System.Configuration;
using System.Text;
using System;

namespace LDAPModule
{
    public class LDAPHelper
    {
        /// <summary>
        /// 在域上验证用户
        /// </summary>
        /// <returns></returns>
       public static bool VerifyDomainUser(string userName,string password)
        {
            string LDAPPath = "LDAP://" + "10.20.18.10";
            DirectoryEntry entry = new DirectoryEntry(LDAPPath, userName, password);
            try
            {
                //绑定到本机 AdsObject 以强制身份验证。
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + userName + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult sr = search.FindOne();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}


