﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BugGeneration.WebReference;
using System.IO;
using LDAPModule;


namespace BugGeneration
{
    public class BugManager
    {
        public int TestId { get; set; }

        public void TestMethod()
        {
            Console.WriteLine("TestMethod()");
        }

        /// <summary>
        ///调用Bug管理平台的接口，录入bug
        /// </summary>
        /// <param name="bmPak"></param>
        /// <param name="userName"></param>
        /// <param name="passWord"></param>
        public void SendBugPak(BMPak bmPak, string userName, string passWord, int projectId)
        {
            if (LDAPHelper.VerifyDomainUser(userName, passWord))
            {
                try
                {     
                    IMSService service = new IMSService();
                    bmPak.ResolveVersion = string.Empty;
                    service.AddFullBug(bmPak, userName, passWord, projectId);
                    Console.WriteLine("Send Sucess");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.StackTrace);
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                Console.WriteLine("帐密不正确");
            }
        }

/// <summary>
/// 提取客户端的版本号
/// </summary>
/// <param name="clientPath"></param>
/// <returns></returns>
        public string GetVersion(string clientPath)
        {
            var clientVersion = "";
            FileStream ffileStream = new FileStream(clientPath + @"\" + "version.cfg", FileMode.Open);
            StreamReader streamReader = new StreamReader(ffileStream);
            string versionConfig = streamReader.ReadToEnd();
            var beginIndex = versionConfig.IndexOf("Sword3.version=");
            var endIndex = versionConfig.IndexOf("\r", beginIndex + 15);

            //获取的版本号格式为a-b-c-d将其转换为a.b.c.d
            clientVersion = versionConfig.Substring(beginIndex + 15, endIndex - beginIndex - 15).Replace("-", ".");
            return clientVersion; 
        }

        public static void Test()
        {
            Console.WriteLine("Test Function");
        }

    }
}
