module("DataSource",package.seeall)

require "tab"

local tabList = {}

function GetTab( filePath )
	if( tabList[filePath] == nil ) then
		collectgarbage("collect");
		tabList[filePath] = tab.Open( filePath );
	end
	
	return tabList[filePath];
end
