module( "PatternMatcher" , package.seeall )

contex =  contex or {}
tabcontex = tabcontex or {}

local proxy = {}	
local mt = {  
	__index = function(t,k) 
			if( contex[k] ) then  
				return contex[k];
			elseif( tabcontex[k] ) then  
				return tabcontex[k];		
			elseif( global_env[k] ) then
				return global_env[k];
			else
				error("attempt to access a nil val :"..tostring(k));
			end 
		end,
	__newindex = function(t,k,v) 
				rawset(contex,k,v);
			end 
}
setmetatable( proxy,mt );


local function SetUpRuleFuncContex( rules ) 
	for i,rule in ipairs( rules ) do
		setfenv( rule.process , proxy );
	end
end


local function TeardownRuleFuncContex( rules ) 
	contex = {};
end


local function SetUpData( dataSet,dataSource )
	for i,v in ipairs( dataSet ) do 
		local val = tonumber( dataSource[v] )
		local def = nil
		if( val == nil ) then
			def = loadstring( string.format( "%s = %s" ,v,  "\""..dataSource[v].. "\"" ) );
		else
			def = loadstring( string.format( "%s = %d" ,v,  val ) );
		end
		setfenv(def,proxy );
		def();
	end
end


local function CheckDataField( fields,tab,fieldNotExits )
	local fieldNotExits = fieldNotExits or {};
	for i,v in ipairs( fields ) do
		local index = -1;
		for j,indexVal in ipairs( tab.tIndexTable ) do
			if( indexVal == v ) then
				index = j;
				break;
			end
		end
		
		if( index == -1 ) then
			fieldNotExits[ #fieldNotExits + 1 ] = v;
		end
	end
	
	return fieldNotExits;
end

local function GetOrgRuleStr( str )
	if( string.sub( str , 1,6 ) == "return" ) then
		return string.match(str ,"return ([%w%p%s]*)$");
	else
		return str;
	end
end

--[[
errRecords = {
				1={
					recordIndex=numberType,       --匹配出错的记录，第几条
					mismatchRule=""				  --匹配出错的规则字符串
				}
			}
]]
function MatchRules( tab, rules, varname, reference )
	
	local errRecords = {};
	
	local set =	CheckDataField({varname}, tab);
	set = CheckDataField( reference or {},tab, set );
	if( #set ~= 0 ) then
		for i,v in ipairs( set ) do
			errRecords[#errRecords + 1] = { ["recordIndex"] = -1,["mismatchRule"] = "[ target/reference Error ] : errMsg =  field ["..v.."]  not exits." };
		end
		
		return errRecords;
	end
	
	SetUpRuleFuncContex( rules );
	
	for recordIndex,record in ipairs( tab ) do 
		SetUpData( {varname},record );
		SetUpData( reference or {},record );
		
		for ruleIndex, rule in pairs( rules ) do
			local status,_,descripMsg   = pcall( rule.process );	
			
			if( not status or _ == nil) then
				local orgRuleStr = GetOrgRuleStr( rule.ruleStr );
				errRecords[#errRecords + 1] = { ["recordIndex"] = record[tab.tIndexTable[1]],["mismatchRule"] = "[ Rule Error ] : errMsg = " .. (_ or "").."   \nRuleStr = "..orgRuleStr};
				rules[ruleIndex] = nil;
			elseif( _ == false ) then
				errRecords[#errRecords + 1] = { ["recordIndex"] = record[tab.tIndexTable[1]],["mismatchRule"] = "[ Rule Mismatch ] : " ..descripMsg };
			end
		end
	end
	
	TeardownRuleFuncContex( rules );
	
	return errRecords;
end