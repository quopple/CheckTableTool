
CheckTablePath = [[D:\CheckTable\CheckTable]];

dofile(CheckTablePath.."\\checktable.lua");
dofile(CheckTablePath.."\\clientpath.lh");

require "DataSource"
require "PatternMatcher"
require "ScripParser"


--设置当前工作路径
lfs.chdir(ClientPath);

global_env  = nil;
getfenv_old = nil;
dataSrc = nil

local function SetUpGlobalContex() 
	global_env = getfenv(0);
	getfenv_old = getfenv_old or getfenv;
	getfenv = function( v ) 
		if getfenv_old( v ) == getfenv_old(0) then
			return nil;
		end
		return getfenv_old( v );
	end
end


local function TeardownGlobalContex() 
	getfenv = getfenv_old;
	global_env  = nil;
	getfenv_old = nil;
end


local function SetUpRuleTabEnv( tabRules )
	dataSrc = DataSource.GetTab( tabRules.tabPath );
	
	if( tabRules.refTab ~= nil ) then
		for i,tabItem in ipairs( tabRules.refTab ) do
			local tab = DataSource.GetTab( tabItem.tabPath );

			PatternMatcher.tabcontex[tabItem.alias] = tab
		end
	end
end


local function TeardownRuleTabEnv()
	PatternMatcher.tabcontex = {}
end


local function ErrorRuleReport( errRules )
--[[
errRules = {
				1={
					msg="",     --规则函数编译错误信息
					mail=""		--要通知的负责人
				},
				2={......}
			}
]]
	for i,v in ipairs(errRules) do
		check.LogError(v.msg.."  "..v.mail);
	end
end


local function ErrorRecordReport( target, errRecords )
	for i,v in ipairs(errRecords) do
		check.LogError( string.format("recordIndex :[ %s ]\tfield :[ %s ]\t\tDetail :%s",v.recordIndex, target, v.mismatchRule));
	end
end


function Exec()
	SetUpGlobalContex();
	
	local status,ruleTable,errRules = pcall( ScripParser.Parse, arg[2] );
	if( not status ) then
			check.LogError( "Parser error." );
			check.LogError( ruleTable );
			return;
	elseif( #errRules ~= 0 )  then
		ErrorRuleReport( errRules );
	end

	for tabRulesIndex,tabRules in ipairs( ruleTable ) do
		SetUpRuleTabEnv( tabRules );
	
		local needWriteHead = true
		for ruleFieldIndex, ruleField in ipairs( tabRules.ruleFields ) do	
			local errRecords = PatternMatcher.MatchRules( dataSrc,ruleField.rules,ruleField.varname,ruleField.reference );
			if( #errRecords ~= 0 ) then
				if( needWriteHead ) then
					check.LogError( "-----------------------------------------------------" );
					check.LogError( tabRules.tabPath );
					needWriteHead = false;
				end
				ErrorRecordReport(ruleField.varname, errRecords );
			end
		end

		TeardownRuleTabEnv( tabRules );
	end
	
	TeardownGlobalContex();
end



if( #arg == 3 and arg[2] == "-t" ) then
	local status,_,errRules = pcall( ScripParser.Parse, arg[3] );
	if( not status ) then
		check.LogError( "Parser error." );
		check.LogError( _ );
	elseif( #errRules ~= 0 )  then
		ErrorRuleReport( errRules );
	else 
		print( "Success." );
	end
elseif( #arg == 2 ) then
	Exec();
else
	print( "Usage:  lua.exe   Agenda.lua   logFilePath  [-t]  ruleFilePath" );
	print( "Mark :  With -t only test the ruleFile.Else run the ruleFile.")
end

