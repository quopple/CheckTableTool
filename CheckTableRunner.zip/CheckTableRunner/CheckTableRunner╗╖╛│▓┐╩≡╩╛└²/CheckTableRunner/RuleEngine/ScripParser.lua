 module( "ScripParser" , package.seeall )
 
 local function defaultFailFun( )
	return nil;
 end
 
 
 
 
 --[[
 ruleTable = {  1={
					tabPath="",					--处理的配置表的绝对路径
					[refTab={ 1={ tabPath="",alias="" },2={...} }]  --可选字段，该配置表所有规则所需要引用的其他表
					email="",					--对该配置表定义的规则文件解析出错时通知的负责人
					ruleFields={ 
						1={ 
							varname="",			--配置表的一个字段，以下规则针对该字段值
							[reference={1="",2="" }] --可选字段，规则中需要引用的其他变量的名的列表
							[email="",]             --可选字段，没有时使用tabPath对应的email，规则出错时通知的负责人
							rules={ 				--对该字段定义的规则集
									1={
										process=functionType,	--规则函数（符合lua语法），返回一个布尔值
										ruleStr=""				--规则函数的字符串，用于错误信息
									},
									2={.........} 
								} 
						},
						2={.......} 
					} 
				} ,
				2={} 
			}
errRules = {
				1={
					msg="",     --规则函数编译错误信息
					mail=""		--负责人
				},
				2={......}
			}
 ]]
 
 local function parseToLuaFuncStr( str )
	if not string.find( str,"return " ) then
		str = "return "..str;
	end
	
	return str;
 end
 
 
 function Parse( fileName )
	local file = io.open( fileName );
	local isHead = true;			--是否是新的一个配置表的规则，即ruleTable中的一项
	local ruleTable = {};
	local ruleStr = "";
	local refTab = nil;
	local errRules = {};
	local lineCounter = 0;			--用于记录规则文件的当前解析行

	for line in file:lines() do
		lineCounter = lineCounter + 1;
		local label = string.match( line,"^#(%w+)%s*");

		if( label == "table" ) then
			isHead = true;
			local tabPath = string.match(line, "%s+([%w%p]+)$");
			ruleTable[#ruleTable + 1] = { ["tabPath"] = tabPath ,["ruleFields"]={}};
		elseif( label == "refTable" ) then
			if( ruleTable[#ruleTable].refTab == nil ) then
				ruleTable[#ruleTable].refTab = {};
				refTab = ruleTable[#ruleTable].refTab;
			end 
			local path,alias = string.match( line,"%s+([%w%p]+)%s+as%s+([%w%p]+)$" );
			refTab[#refTab+1] = { ["tabPath"] = path, ["alias"] = alias};
		elseif( label == "email" ) then
			local mail = string.match( line, "[%w_-]+@[%w_-]+%.[%w_-]+$" );

			if( isHead ) then
				ruleTable[#ruleTable].email = mail;
			else
				local ruleFields = ruleTable[#ruleTable].ruleFields;
				ruleFields[#ruleFields].email = mail;
			end
			
		elseif( label == "target" ) then
			isHead = false;
			local varname = string.match( line,"[%w_]+$" );
			local ruleFields = ruleTable[#ruleTable].ruleFields;
			ruleFields[#ruleFields + 1] = { ["varname"] = varname };
		elseif( label == "reference" ) then
			local itr = string.gmatch( line,"%s([%w_]+)" );
			local ruleFields = ruleTable[#ruleTable].ruleFields;
			ruleFields[#ruleFields].reference = {};
			local referenceTable = ruleFields[#ruleFields].reference
			for ele in itr do 
				table.insert(referenceTable, ele );
			end	
		elseif( label == "ruleBegin" ) then
			local ruleFields = ruleTable[#ruleTable].ruleFields;
			ruleFields[#ruleFields].rules = {}
		elseif( label == nil or label == "ruleEnd" ) then
			if( string.len( line ) ~= 0 ) then
				local isRuleHead = string.find( line,"^-" );
				
				if( isRuleHead or label == "ruleEnd" ) then
					local ruleFields = ruleTable[#ruleTable].ruleFields;
					local rules = ruleFields[#ruleFields].rules
					
					if( string.len(ruleStr)~= 0 ) then
						ruleStr = parseToLuaFuncStr( ruleStr );
						local func,errMsg = loadstring( ruleStr )			
						if( func == nil ) then
							local msg  = string.format( "path := %s  line := %d  errMsg := %s",fileName,lineCounter-1,errMsg );
							local mail = ruleFields[#ruleFields].email or ruleTable[#ruleTable].email;
							errRules[#errRules+1] = { ["msg"] = msg, ["mail"] = mail };
							func = defaultFailFun;
						end
						table.insert( rules,{ ["process"] = func, ["ruleStr"] = ruleStr});
					end
					
					if( isRuleHead ) then
						local s,e = string.find( line ,"^-%s+" );
						if( e ~= #line ) then
							ruleStr = string.sub( line, e+1, -1 );
						else
							ruleStr = "";
						end					
					else
						ruleStr = "";
					end
					
				else
					ruleStr = ruleStr.. " "..line;
				end
				
			end
		end
	end
	
	file:close();
	
	return ruleTable,errRules;
 end