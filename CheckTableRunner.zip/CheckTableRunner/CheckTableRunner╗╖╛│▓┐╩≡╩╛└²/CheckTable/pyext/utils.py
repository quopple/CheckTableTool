import lua
def LuaObj(pyObj, encoding='gbk'):
	def _seq2lua(o):
		ret = lua.eval('{}')
		for i,v in enumerate(o):
			ret[i] = LuaObj(v)
		return ret
	def _dict2lua(o):
		ret = lua.eval('{}')
		for k in o:
			ret[k] = LuaObj(v)
	def _encode(o):
		return o.encode(encoding)

	handlers = {
		dict: _dict2lua,
		list: _seq2lua,
		tuple: _seq2lua,
		unicode: _encode
	}
	if type(pyObj) in handlers:
		return handlers[type(pyObj)](pyObj)
	return pyObj