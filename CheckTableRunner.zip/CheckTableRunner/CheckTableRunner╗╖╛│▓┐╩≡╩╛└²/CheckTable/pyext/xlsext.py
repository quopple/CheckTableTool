#coding: gbk
import xlrd
import lua
from .utils import LuaObj

def int_to_excle_colname(x):
	t = range(ord('A'),ord('Z') + 1)
	ret = []
	while x >= 0:
		ret.append(chr(t[x % 26]))
		x = x / 26 - 1
	return ''.join(ret[::-1])

def validate_duplicate_headers(headers, rowNum):
	tmp=[]
	for i,h in enumerate(headers):
		try:
			j = tmp.index(h)
			raise Exception("��%d�в�����Ϊ��ͷ, ��Ϊ���%d�к͵�%d���ظ�, ��Ϊ%s" % (
					rowNum + 1,
					i + 1,
					j + 1,
					h
				))
		except ValueError:
			pass
		tmp.append(h)

def OpenXls(init_func, fileName, tab, startRow=0):
	def fillBlankHeaders(row):
		for i,v in enumerate(row):
			if not v:
				row[i] = 'Column%s' % int_to_excle_colname(i)
	luaTable = lua.eval('table')
	luaTabRet = init_func() if init_func else lua.eval('{}')
	ei = 0
	err_msg = [
		"Can't read %s" % fileName,
		"Can't Load index: %s" % tab,
		"Sorry Dave, I can't process this file..."
	]
	if True:
	#try:
		xl = xlrd.open_workbook(fileName)
		ei += 1
		sheet = None
		if type(tab) is int:
			sheet = xl.sheet_by_index(tab)
		elif type(tab) is str:
			sheet = xl.sheet_by_name(tab.decode('gbk'))
		ei += 1
		headers = sheet.row_values(startRow)
		fillBlankHeaders(headers)
		headers = map(LuaObj, headers)
		#assert len(headers) == len(set(headers)), headers
		validate_duplicate_headers(headers, startRow)
		luaTabRet['tIndexTable'] = lua.eval('{}')
		tLuaHeader = luaTabRet['tIndexTable']
		for i, v in enumerate(headers):
			tLuaHeader[i+1] = v
		for rowNum in xrange(startRow + 1, sheet.nrows):
			assert len(sheet.row_values(rowNum)) == len(headers), rowNum
			luaTabRet[rowNum - startRow] = lua.eval('{}')
			tLuaTable = luaTabRet[rowNum - startRow]
			sh_rv = sheet.row_values(rowNum)
			for i,h in enumerate(headers):
				tLuaTable[h] = LuaObj(sh_rv[i])
	#except:
	#	print err_msg[ei]
	#	return None
	return luaTabRet
