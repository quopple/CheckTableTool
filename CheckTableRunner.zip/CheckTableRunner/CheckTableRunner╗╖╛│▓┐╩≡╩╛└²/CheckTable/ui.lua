module("ui", package.seeall)

require "io"
require "unclasslib"

require "jdotnet"
require "jstring"
require "jdebug"

require "doNetCheckTableAuxiliary"
require "check"
require "math"

local dataObj = DoNetDataIOFile()

--�������Ϊ.tab��ʽ����ͨ��excel�Զ���
function ShowResault(tableFile,saveName)
--~ 	local dataObj = DoNetDataIOFile()
	local tableIndex = {}
	dataObj:InitializeTable()
	--����c#��һ��List�������洢��ͷ
	local tableHeader = dataObj.ResultTableHeader	
	--�������������ݵ��б���
	for _,v in pairs(tableFile.tIndexTable) do 
		tableHeader:Add(v)
	end
	
	--����lua���е�ÿһ�У����������ӵ�c#��l�������ݵ�ist��
	for _,row in pairs(tableFile) do
	--���ڴ����table������lua�е�ԭ��table�������һ����bool������table�����Ҫ����һ���жϲ���ȷ����ȫ
		if (type(row) == "table") then
			local newRow = dataObj:CreateNewRow()
				for _,v in ipairs(tableFile.tIndexTable) do
					if (row[v] == nil) then
						newRow:Add("")
					else
						newRow:Add(row[v])				
				    end
			    end
			dataObj:AddRow(newRow)
		end
	end 
		if (saveName == nil) then
			saveName = ""
		end
		
	    dataObj:ProcessResult(saveName)
end

function GetFlsChdir()
--~ 	local dataObj = DoNetDataIOFile()
	local cmdArg = dataObj:GetFlsChdir()
	if cmdArg == "io.stdout:setvbuf 'no'" then
		cmdArg = ""
	end
	return cmdArg
end

function GetRunningScriptName()
--~ 	local dataObj = DoNetDataIOFile()
	local cmdArg = dataObj:GetRunningLuaScriptName()
	if cmdArg == "io.stdout:setvbuf 'no'" then
		cmdArg = ""
	end
	return cmdArg
end

local textboxId = 0
local comboboxId = 0
local checkboxId = 0

function Button()
	local button = {}
	button["Flag"] = "Button"
	button["Text"] = "button"
	button["Width"] = 0
	button["Height"] = 0
	return button
end

function ComboBox()
	local combobox = {}
	combobox["Flag"] = "ComboBox"
	combobox["Text"] = "combobox"
	combobox["Width"] = 0
	combobox["Height"] = 0
	return combobox
end

function TextBox()
	local textbox = {}
	textbox["Flag"] = "TextBox"
	textbox["Width"] = 0
	textbox["Height"] = 0
	return textbox
end

function Label()
	local label = {}
	label["Flag"] = "Label"
	label["Text"] = "label"
	label["Width"] = 0
	label["Height"] = 0
	return label
end

function CheckBox()
	local checkbox = {}
	checkbox["Flag"] = "CheckBox"
	checkbox["Checked"] = false
	checkbox["Text"] = "CheckBox"
	checkbox["Width"] = 0	
	checkbox["Height"] = 0
	return checkbox
end

function GetData(TextBox)
	local t = GetTextBoxContext(TextBox)
	local re
	local mode = dataObj:GetBindComboboxState(TextBox["Id"])
	if string.find(mode,',') then
		re = string.split(mode,',')
	else
		re = mode
	end
	return t,mode
end

function GetCheckBoxState(CheckBox)
	local controlId = CheckBox["Id"]
	local resault = dataObj:GetCheckBoxState(controlId)
	return resault
end

function GetTextBoxContext(TextBox)
	local controlId = TextBox["Id"]
	local resault = dataObj:GetInputContext(controlId)
	local length = dataObj:GetListCount(resault);
	local t = {}
	
	if (length > 0) then
		for i = 0,length-1,1 do
			local tableItem = {}
			if string.startsWith(resault[i],"{") then
				print(resault[i])
				local endIndex =string.find(resault[i],"}")
				local context = string.sub(resault[i],2,endIndex - 1)
				local row = string.split(context,",")
				for _,v in ipairs(row) do
					if (tonumber(v)) then
						table.insert(tableItem,tonumber(v))
					else
						table.insert(tableItem,v)
					end
				end
				table.insert(t,tableItem)
			else			
				local item = tonumber(resault[i])
				if (item) then
					table.insert(t,item)
				else
					table.insert(t,resault[i])
				end
			end
		end
	end 
	return t
end

function AddControl(flag,control)
	local width,height
		width = control["Width"] 
		height = control["Height"] 
	if (control["Flag"] == "TextBox") then
		control["Id"] = textboxId
		dataObj:AddControl(flag,control["Flag"],width,height,"")	
		textboxId = textboxId + 1
	end
	
	if (control["Flag"] == "Label") then
		dataObj:AddControl(flag,control["Flag"],width,height,control["Text"])	
	end
	
	if (control["Flag"] == "Button") then
		dataObj:AddControl(flag,control["Flag"],width,height,control["Text"])
	end
	
	if (control["Flag"] == "CheckBox") then
		control["Id"] = checkboxId
		dataObj:AddControl(flag,control["Flag"],width,height,control["Text"], control["Checked"])		
		checkboxId = checkboxId + 1
	end
	
	if (control["Flag"] == "ComboBox") then
		control["Id"] = comboboxId		
		local context = ""
		if (control["Items"] ~= nil) then
			for k,v in ipairs(control["Items"]) do
				if (k == 1) then
					context = v
				else
					context = context .. ',' .. v
				end
			end
		end
		dataObj:AddControl(flag,control["Flag"],width,height,context)	
		comboboxId = comboboxId + 1	
	end	
end

function Show()
	dataObj:ShowDialog()
end
	
	
function Bind(textbox,combobox)
	dataObj:ControlBind(textbox["Id"],combobox["Id"])
end

function SetCollumnGap(row,size)
	dataObj:SetCollumnGap(row,size)
end

function SetRowGap(startRow,endRow,size)
	dataObj:SetRowGap(startRow,endRow,size)
end

function SetEdge(hor,ver)
	dataObj:SetEdge(hor,ver)
end

function SetFormName(name)
	dataObj:SetFormName(tostring(name))
end

function GetComboxSelectedItem(combobox)
	return dataObj:GetComboBoxState(combobox["Id"])
end