if not CheckTablePath then
	error("CheckTablePath must be set")
end

package.path = CheckTablePath.."\\?.lua;"..package.path -- To load other .lua file under CheckTable/
package.cpath = CheckTablePath.."\\?.dll;"..package.cpath -- To load CheckTable/luanet.dll

require "tab"
require "check"
require "jstring"
require "jtable"
require "jpath"
require "math"
require "pl.config"
require "rex"
require "ui"
